============================================================
COSMIC STORE — Website + FREE 3-HOUR DEMO SYSTEM
(Aapki personal developer website, same premium design)
================================================------------

★ CLOUD MODE (FIREBASE) — SABSE PEHLE YE PADHO
Website ka poora data (products, content, messages, demos) ab
FIREBASE CLOUD me rehta hai. One-time 5-minute setup ke baad
website 24/7 online rahegi — aapka PC band bhi ho tab bhi.
Poori guide: FIREBASE-SETUP.txt (ye padhna ZAROORI hai)

★ YE KYA HAI?
1. Aapki apni developer website — services, work, reviews,
   WhatsApp contact, contact form (messages aapke panel me aate hain)
2. OWNER ADMIN PANEL — aap sab kuch control karte ho
3. DEMO SYSTEM — client ko 3-ghante ka ID/Pass do, wo ek REAL
   website ka admin panel khud chala kar dekhta hai ki control
   kaisa milega. Demo time ke baad khud band ho jata hai.

============================================================
1. LOCAL PREVIEW KAISE CHALAYEIN (testing ke liye)
============================================================
Step 1: Node.js install hona chahiye (nodejs.org se — LTS version)
Step 2: Is folder me Command Prompt / PowerShell kholo
Step 3: Ye command chalao (sirf pehli baar):
        npm install
Step 4: Ab server chalao:
        npm start
Step 5: Browser me kholo:
        http://localhost:3000

Server window band karoge to website band ho jayegi.
Dobara chalane ke liye bas: npm start

============================================================
2. OWNER ADMIN PANEL (aapka control room)
============================================================
Link:     http://localhost:3000/admin.html
Login:    username = admin
          password = admin123    ← PEHLE LOGIN KE BAAD TURANT
                                    SETTINGS TAB SE PASSWORD BADLO!

Tabs:
  📊 Overview     — kitne active demos, unread messages, projects
  🎟 Demo Accounts — client ke liye 3-ghante ka ID/Pass banao
  💎 Site Content — poori website ka content (naam, hero, services,
                    projects, reviews, WhatsApp number, email)
  💬 Messages     — contact form se aaye messages (WhatsApp reply
                    button bhi milta hai)
  ⚙ Settings     — apna password badlo

============================================================
3. DEMO SYSTEM KAISE KAAM KARTA HAI (aasaan flow)
============================================================
★ DEMO = ek ready-made E-COMMERCE SHOPPING WEBSITE (AAPKI DUKAAN)
  jisme products, prices, cart aur WhatsApp orders hain.
  Client isi ko admin panel se control karta hai. Aapki apni
  portfolio website (jo ads me dikhti hai) isse BILKUL ALAG hai —
  demo me kuch bhi karo, wo kabhi nahi badalti.

Step 1: Client aapse WhatsApp par demo maangta hai
Step 2: Aap admin.html → Demo Accounts tab
        - Pehle SECURITY PIN daalo (default: 8307248147)
          (PIN ke bina demo BANTA HI NAHI — koi aur account nahi
           bana sakta. PIN Settings tab se badal sakte ho.)
        - Client ka naam likho → "Demo ID/Pass Banao" dabao
Step 3: ID + Password + Login link copy karke WhatsApp par bhej do
Step 4: Client demo-login.html par login karta hai
Step 5: Uske saamne khulta hai STORE CONTROL PANEL — store ka
        naam, announcement, products, prices, stock, categories,
        reviews sab wo khud badalta hai
Step 6: "Store Kholo" dabao — USKI shopping website khulti hai:
        - uske products, uske prices (discount % apne aap)
        - customer cart me daal ke WhatsApp par ORDER kar sakte hain
        - uske changes 8 second me apne aap live dikhte hain
Step 7: 3 ghante baad demo APNE AAP khatam:
        - client ki site par auto-logout ho jata hai
        - us ID/Pass se dubara login BAND — kaam khatam

Aap demo ko beech me bhi badha sakte ho (+3h), reset kar sakte ho
(original products wapas), ya delete kar sakte ho.

============================================================
4. APNA WHATSAPP NUMBER / NAAM DALNA (sabse zaroori!)
============================================================
Website me abhi sample data hai. Sab badalne ke 2 tarike:

TARIKA A (aasaan — panel se):
  admin.html → Site Content tab
  - Site Ka Naam (e.g. SANREET / DEV)
  - Tagline
  - Hero text
  - WhatsApp Number: 91XXXXXXXXXX (country code saath, + nahi)
  - Email
  - Services / Projects / Reviews
  → "Save All Changes" dabao — website turant update!

TARIKA B (files se):
  data/site.json file kholo aur edit karo.

LOGO badalna ho to: public/logo.jpg replace kar do
(usi naam se — purani photo ko delete karke nayi photo ka naam
"logo.jpg" rakh do).

============================================================
5. FOLDERS / FILES
============================================================
server.js          — poora system (server + login + demo)
public/            — website ke pages
  index.html       — Home
  services.html    — Services + process
  work.html        — Portfolio (projects)
  contact.html     — WhatsApp + contact form
  faq.html         — Common questions
  demo-login.html  — Client demo login
  demo-admin.html  — Client demo control panel
  demo-site.html   — Client ki demo website
  admin.html       — AAPKA owner panel
  style.css        — design | script.js / admin.js / demo.js — logic
data/              — sab data yahan save hota hai (JSON files)
  config.json      — aapka login (password hashed hai)
  site.json        — website ka content
  demos.json       — demo accounts + expiry time
  messages.json    — contact form messages
  sandbox-*.json   — har demo client ka apna alag content

★ BACKUP: bas data/ folder copy kar lo. Bas.
★ data/ folder delete karoge → sab reset ho jayega (naya
  password admin/admin123 ho jayega).

============================================================
6. MOBILE / DUSRE LAPTOP PAR DEKHNA (same WiFi)
============================================================
Server chalu karne par console me ek "WiFi/phone par" wala
address aata hai (aapke computer ka IP, jaise 192.168.x.x).
Wo address phone ke browser me kholo — same WiFi ho to chalega.
Internet ke liye hosting chahiye (neeche dekho).

============================================================
7. INTERNET PAR KAISE LAGAYEIN (FREE)
============================================================
Ye website Node.js server maangti hai (demo system ke liye),
isliye Netlify drag-drop nahi chalega. Free options:

RENDER.COM (recommended, free):
  1. render.com par account banao
  2. "New Web Service" → is folder ko GitHub par daalo
  3. Build command: npm install
     Start command: npm start
  4. Free link mil jayega (jaise sanreetdev.onrender.com)

RAILWAY.APP bhi aasaan hai (same steps).

Admin panel link kisi ko na do — sirf apne paas rakho.

============================================================
8. SECURITY (dhyan rakhne wali baatein)
============================================================
- admin/admin123 default hai — FIRST DAY me hi change karo
- Demo PIN (8307248147) bhi Settings se jaldi change karo —
  ye PIN ke bina koi demo account bana hi nahi sakta
- Demo passwords random generate hote hain, sirf ek baar dikhte hain
- Demo ID/Pass sirf 3 ghante chalete hain — expire ke baad
  auto-logout + us ID/Pass se dubara login band
- 5 galat login tries → 10 minute ka lock
- Client demo me kuch bhi kare, aapki website safe rehti hai
  (demo sirf apne alag STORE sandbox me kaam karta hai)
- Server restart par sab data data/ me safe rehta hai

============================================================
Koi problem aaye: server window me error padho, ya mujhe
(jo banaya hai 😄) WhatsApp kar do.
============================================================
