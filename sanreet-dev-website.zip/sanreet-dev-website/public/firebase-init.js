/* ============================================================
   FIREBASE — Analytics + Firestore + Owner Auth
   ------------------------------------------------------------
   AB ARCHITECTURE CLOUD HAI:
   - Products / site content / demo accounts / messages SAB
     Firebase Firestore (cloud database) me rehte hain
   - Website free hosting (Netlify) par 24/7 chalegi —
     aapka PC band bhi ho tab bhi
   - Admin panel se change karo → cloud update → users ko
     LIVE dikhta hai (bina refresh ke bhi, onSnapshot se)

   One-time setup: FIREBASE-SETUP.txt padho (5 minute)

   Firestore structure:
     site/content          → portfolio website ka content
     store/default         → demo store ka original content
     demos/{username}      → demo accounts {passHash, label, expiresAt}
     sandboxes/{username}  → har demo client ka apna store content
     messages/{auto}       → contact form messages (cloud)
     config/private        → demo PIN hash (sirf owner padh sakta hai)
   ============================================================ */

import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import { getAnalytics, logEvent } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-analytics.js";
import {
  getFirestore,
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  updateDoc,
  deleteDoc,
  addDoc,
  onSnapshot,
  query,
  orderBy,
  limit,
  serverTimestamp,
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";
import {
  getAuth,
  signInWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  updatePassword,
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";

const firebaseConfig = {
  apiKey: "AIzaSyDPPVFo9XGvixrGeIkijrmUNHOleJlI8ts",
  authDomain: "fir-website-43ca2.firebaseapp.com",
  projectId: "fir-website-43ca2",
  storageBucket: "fir-website-43ca2.firebasestorage.app",
  messagingSenderId: "479802578772",
  appId: "1:479802578772:web:e663df8b39dedfda465ac1",
  measurementId: "G-M68QPCNWLX",
};

let app = null,
  analytics = null,
  db = null,
  auth = null;
try {
  app = initializeApp(firebaseConfig);
  try {
    analytics = getAnalytics(app);
  } catch (_) {}
  db = getFirestore(app);
  auth = getAuth(app);
} catch (e) {
  console.warn("Firebase load nahi hua:", e && e.message);
}

/* ---------- helpers ---------- */
async function sha256(text) {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
  return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

function fbErr(e) {
  const code = (e && (e.code || e.message) || "").toString();
  if (code.includes("permission-denied"))
    return "Permission nahi hai — FIREBASE-SETUP.txt me diye rules paste karo.";
  if (code.includes("configuration-not-found") || code.includes("operation-not-allowed") || code.includes("auth/unauthorized-domain"))
    return "Firebase Authentication abhi set nahi hui — FIREBASE-SETUP.txt Step 3 dekho.";
  if (code.includes("not-found")) return "Data nahi mila (abhi tak bana nahi).";
  if (code.includes("unavailable") || code.includes("failed-precondition"))
    return "Firestore Database abhi bana nahi — FIREBASE-SETUP.txt Step 2 dekho.";
  if (code.includes("invalid-credential") || code.includes("wrong-password") || code.includes("user-not-found"))
    return "Galat email ya password.";
  if (code.includes("too-many-requests")) return "Bahut tries — thodi der baad try karo.";
  if (code.includes("requires-recent-login")) return "Pehle logout karke dobara login karo, phir try karo.";
  if (code.includes("weak-password")) return "Password kam se kam 6 characters ka ho.";
  if (code.includes("network")) return "Internet nahi chal raha.";
  return e && e.message ? e.message : "Kuch galat ho gaya.";
}

/* Global event log (Analytics) */
window.fbLog = function (name, params) {
  try {
    if (analytics) logEvent(analytics, name, params || {});
  } catch (_) {}
};

/* Global contact-message cloud save */
window.fbSaveMessage = async function (msg) {
  if (!db) return false;
  try {
    await addDocMessage(msg);
    return true;
  } catch (e) {
    console.warn("Firestore message save fail:", fbErr(e));
    return false;
  }
};

async function addDocMessage(msg) {
  await addDoc(collection(db, "messages"), {
    name: String(msg.name || "").slice(0, 120),
    email: String(msg.email || "").slice(0, 160),
    phone: String(msg.phone || "").slice(0, 30),
    message: String(msg.message || "").slice(0, 3000),
    at: Date.now(),
    serverTime: serverTimestamp(),
    read: false,
    ua: (navigator.userAgent || "").slice(0, 200),
  });
}

/* ============================================================
   window.fb — poora cloud data API (pages yahi use karte hain)
   ============================================================ */
window.fb = {
  ok: () => !!db,

  /* ---------------- OWNER AUTH ---------------- */
  ownerLogin: async (email, pass) => {
    if (!auth) return { ok: false, error: "Firebase load nahi hua." };
    try {
      await signInWithEmailAndPassword(auth, email.trim(), pass);
      return { ok: true };
    } catch (e) {
      return { ok: false, error: fbErr(e) };
    }
  },

  ownerLogout: async () => {
    try {
      auth && (await signOut(auth));
    } catch (_) {}
  },

  ownerEmail: () => (auth && auth.currentUser ? auth.currentUser.email : null),

  onOwner: (cb) => {
    if (!auth) {
      cb(null);
      return;
    }
    onAuthStateChanged(auth, (u) => cb(u ? u.email : null));
  },

  changeOwnerPassword: async (newPass) => {
    if (!auth || !auth.currentUser) return { ok: false, error: "Pehle login karo." };
    try {
      await updatePassword(auth.currentUser, newPass);
      return { ok: true };
    } catch (e) {
      return { ok: false, error: fbErr(e) };
    }
  },

  /* ---------------- SITE CONTENT (portfolio) ---------------- */
  getSite: async () => {
    if (!db) return { ok: false, error: "Firebase load nahi hua." };
    try {
      const snap = await getDoc(doc(db, "site", "content"));
      return { ok: true, site: snap.exists() ? snap.data() : null };
    } catch (e) {
      return { ok: false, error: fbErr(e) };
    }
  },

  saveSite: async (site) => {
    if (!db) return { ok: false, error: "Firebase load nahi hua." };
    try {
      await setDoc(doc(db, "site", "content"), site);
      return { ok: true };
    } catch (e) {
      return { ok: false, error: fbErr(e) };
    }
  },

  watchSite: (cb) => {
    if (!db) return;
    try {
      onSnapshot(doc(db, "site", "content"), (snap) => cb(snap.exists() ? snap.data() : null));
    } catch (_) {}
  },

  /* ---------------- DEMO STORE DEFAULT ---------------- */
  getStoreDefault: async () => {
    if (!db) return { ok: false, error: "Firebase load nahi hua." };
    try {
      const snap = await getDoc(doc(db, "store", "default"));
      return { ok: true, store: snap.exists() ? snap.data() : null };
    } catch (e) {
      return { ok: false, error: fbErr(e) };
    }
  },

  saveStoreDefault: async (store) => {
    if (!db) return { ok: false, error: "Firebase load nahi hua." };
    try {
      await setDoc(doc(db, "store", "default"), store);
      return { ok: true };
    } catch (e) {
      return { ok: false, error: fbErr(e) };
    }
  },

  /* ---------------- DEMO ACCOUNTS (owner) ---------------- */
  listDemos: async () => {
    if (!db) return { ok: false, error: "Firebase load nahi hua.", demos: [] };
    try {
      const snap = await getDocs(collection(db, "demos"));
      const list = snap.docs.map((d) => ({ username: d.id, ...d.data() }));
      list.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
      return { ok: true, demos: list };
    } catch (e) {
      return { ok: false, error: fbErr(e), demos: [] };
    }
  },

  createDemo: async ({ username, pass, label, hours, pin }) => {
    if (!db) return { ok: false, error: "Firebase load nahi hua." };
    try {
      /* PIN check (owner hi is panel tak pahunch sakta hai, PIN extra lock hai) */
      const pinOk = await window.fb.checkOwnerPin(pin);
      if (!pinOk) return { ok: false, error: "Galat PIN. Demo account nahi bana." };
      const ref = doc(db, "demos", username);
      const existing = await getDoc(ref);
      if (existing.exists()) return { ok: false, error: "Ye username already hai — dobara try karo." };
      const now = Date.now();
      await setDoc(ref, {
        passHash: await sha256(pass),
        label: String(label || "").slice(0, 60),
        createdAt: now,
        expiresAt: now + hours * 3600 * 1000,
      });
      return { ok: true };
    } catch (e) {
      return { ok: false, error: fbErr(e) };
    }
  },

  extendDemo: async (username, hours) => {
    if (!db) return { ok: false, error: "Firebase load nahi hua." };
    try {
      const ref = doc(db, "demos", username);
      const snap = await getDoc(ref);
      if (!snap.exists()) return { ok: false, error: "Demo nahi mila." };
      const d = snap.data();
      const base = Math.max(d.expiresAt || 0, Date.now());
      await updateDoc(ref, { expiresAt: base + hours * 3600 * 1000 });
      return { ok: true };
    } catch (e) {
      return { ok: false, error: fbErr(e) };
    }
  },

  deleteDemo: async (username) => {
    if (!db) return { ok: false, error: "Firebase load nahi hua." };
    try {
      await deleteDoc(doc(db, "demos", username));
      try {
        await deleteDoc(doc(db, "sandboxes", username));
      } catch (_) {}
      return { ok: true };
    } catch (e) {
      return { ok: false, error: fbErr(e) };
    }
  },

  resetDemoSandbox: async (username, storeDefault) => {
    if (!db) return { ok: false, error: "Firebase load nahi hua." };
    try {
      await setDoc(doc(db, "sandboxes", username), JSON.parse(JSON.stringify(storeDefault)));
      return { ok: true };
    } catch (e) {
      return { ok: false, error: fbErr(e) };
    }
  },

  /* ---------------- DEMO CLIENT (ID/Pass login) ---------------- */
  demoLogin: async (username, pass) => {
    if (!db) return { ok: false, error: "Firebase load nahi hua." };
    try {
      const snap = await getDoc(doc(db, "demos", String(username || "").trim()));
      if (!snap.exists()) return { ok: false, error: "Galat ID ya password. Owner se confirm karo." };
      const d = snap.data();
      const hash = await sha256(String(pass || ""));
      if (d.passHash !== hash) return { ok: false, error: "Galat ID ya password. Owner se confirm karo." };
      if ((d.expiresAt || 0) <= Date.now())
        return { ok: false, error: "Ye demo khatam ho gaya hai. Owner (WhatsApp) se naya demo le lo.", expired: true };
      return { ok: true, username: snap.id, label: d.label || "", expiresAt: d.expiresAt };
    } catch (e) {
      return { ok: false, error: fbErr(e) };
    }
  },

  /* Session verify — demo pages load par apne saved session ko check karte hain */
  checkDemo: async (username, passHash) => {
    if (!db) return { ok: false, error: "Firebase load nahi hua." };
    try {
      const snap = await getDoc(doc(db, "demos", String(username || "").trim()));
      if (!snap.exists()) return { ok: false };
      const d = snap.data();
      if (d.passHash !== passHash) return { ok: false };
      if ((d.expiresAt || 0) <= Date.now()) return { ok: false, expired: true };
      return { ok: true, username: snap.id, label: d.label || "", expiresAt: d.expiresAt };
    } catch (e) {
      return { ok: false, error: fbErr(e) };
    }
  },

  getSandbox: async (username, storeDefault) => {
    if (!db) return { ok: false, error: "Firebase load nahi hua." };
    try {
      const snap = await getDoc(doc(db, "sandboxes", username));
      if (snap.exists()) return { ok: true, store: snap.data() };
      /* pehli baar → store/default ki copy banao (ya built-in default) */
      const fresh = JSON.parse(JSON.stringify(storeDefault || {}));
      await setDoc(doc(db, "sandboxes", username), fresh);
      return { ok: true, store: fresh };
    } catch (e) {
      return { ok: false, error: fbErr(e) };
    }
  },

  saveSandbox: async (username, store) => {
    if (!db) return { ok: false, error: "Firebase load nahi hua." };
    try {
      await setDoc(doc(db, "sandboxes", username), store);
      return { ok: true };
    } catch (e) {
      return { ok: false, error: fbErr(e) };
    }
  },

  /* Live updates — owner save kare to demo site turant update ho */
  watchSandbox: (username, cb) => {
    if (!db) return;
    try {
      onSnapshot(doc(db, "sandboxes", username), (snap) => {
        if (snap.exists()) cb(snap.data());
      });
    } catch (_) {}
  },

  /* ---------------- MESSAGES (owner inbox, cloud) ---------------- */
  watchMessages: (cb) => {
    if (!db) return;
    try {
      const q = query(collection(db, "messages"), orderBy("at", "desc"), limit(100));
      onSnapshot(
        q,
        (snap) => {
          cb(snap.docs.map((d) => ({ id: d.id, ...d.data() })));
        },
        () => cb([])
      );
    } catch (_) {
      cb([]);
    }
  },

  markMessageRead: async (id) => {
    if (!db) return;
    try {
      await updateDoc(doc(db, "messages", id), { read: true });
    } catch (_) {}
  },

  deleteMessage: async (id) => {
    if (!db) return;
    try {
      await deleteDoc(doc(db, "messages", id));
    } catch (_) {}
  },

  /* ---------------- DEMO PIN (owner extra lock) ---------------- */
  checkOwnerPin: async (pin) => {
    if (!db) return false;
    try {
      const snap = await getDoc(doc(db, "config", "private"));
      const stored = snap.exists() ? snap.data().demoPinHash : null;
      if (!stored) {
        /* pehli baar → default PIN 8307248147 set ho jata hai */
        const h = await sha256("8307248147");
        try {
          await setDoc(doc(db, "config", "private"), { demoPinHash: h });
        } catch (_) {}
        return pin === "8307248147";
      }
      return (await sha256(String(pin || ""))) === stored;
    } catch (e) {
      return false;
    }
  },

  changeOwnerPin: async (current, next) => {
    if (!db) return { ok: false, error: "Firebase load nahi hua." };
    try {
      if (!/^[0-9]{4,12}$/.test(String(next || "").trim()))
        return { ok: false, error: "PIN sirf numbers me ho, 4 se 12 digits." };
      const okNow = await window.fb.checkOwnerPin(current);
      if (!okNow) return { ok: false, error: "Current PIN galat hai." };
      await setDoc(doc(db, "config", "private"), { demoPinHash: await sha256(String(next).trim()) });
      return { ok: true };
    } catch (e) {
      return { ok: false, error: fbErr(e) };
    }
  },
};

/* pehli baar error-free init confirm */
window.fbReady = Promise.resolve(!!db);
