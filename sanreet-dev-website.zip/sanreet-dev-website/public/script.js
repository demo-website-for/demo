/* ============================================================
   COSMIC STORE — Website Scripts (public pages)
   ------------------------------------------------------------
   ★ Content server (server.js) ke data/ folder se aata hai.
   ★ Owner admin panel se sab badal sakte ho — yahan kuch hard-code
     nahi hai. Neeche FALLBACK_SITE sirf tab use hota hai jab server
     band ho (file:// se kholne par).
   ============================================================ */

/* ---------- Fallback (jab API na chale) ---------- */
const FALLBACK_SITE = {
  brand: { name: "COSMIC", nameAccent: "STORE", tagline: "APPS. WEBSITES. DELIVERED." },
  hero: {
    eyebrow: "INDIVIDUAL APP & WEBSITE DEVELOPER",
    title: "Your Idea,",
    titleShine: "Built For Real.",
    subtitle: "I design and develop mobile apps, websites and admin panels for growing businesses.",
  },
  stats: [
    { value: "25+", label: "Projects Built" },
    { value: "3h", label: "Free Live Demo" },
    { value: "100%", label: "Custom Work" },
    { value: "24/7", label: "Support" },
  ],
  whatsapp: "918766204904",
  email: "hello@example.com",
  services: [
    { icon: "📱", title: "Mobile App Development", desc: "Android apps with modern UI — idea se Play Store tak." },
    { icon: "💻", title: "Website Development", desc: "Fast, premium business websites for every device." },
    { icon: "🛠️", title: "Admin Panels", desc: "Control your whole website from one powerful panel." },
    { icon: "🛒", title: "E-Commerce Stores", desc: "Online store with products, cart and payments." },
    { icon: "🎨", title: "UI / UX Design", desc: "Clean, premium designs your customers love." },
    { icon: "🔧", title: "Maintenance & Support", desc: "Updates, fixes and improvements — always on time." },
  ],
  projects: [
    { name: "ShopKart — Online Store", icon: "🛍️", tag: "E-COMMERCE", status: "LIVE", link: "", description: "E-commerce store with full admin panel and order tracking.", order: 1 },
    { name: "FitTrack — Fitness App", icon: "💪", tag: "ANDROID APP", status: "LIVE", link: "", description: "Workout planner with streaks, charts and reminders.", order: 2 },
    { name: "GlowSalon — Booking Website", icon: "💅", tag: "BUSINESS", status: "LIVE", link: "", description: "Salon website with online appointments and WhatsApp alerts.", order: 3 },
  ],
  reviews: [
    { name: "Rahul Mehta", project: "ShopKart", rating: 5, text: "Meri dukaan ab online hai! Admin panel se khud products add karta hoon." },
    { name: "Priya Sharma", project: "GlowSalon", rating: 5, text: "Website 5 din me ready mili aur bilkul waisi hai jaisi chahiye thi." },
  ],
};

let SITE = null;

/* ---------- Helpers ---------- */
function esc(s) {
  return String(s == null ? "" : s)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function waNumber() {
  return String((SITE && SITE.whatsapp) || "").replace(/[^0-9]/g, "");
}

function waLink(msg) {
  const n = waNumber();
  const text = msg || "Hello! Mujhe apne business ke liye website/app banwani hai.";
  return "https://wa.me/" + n + "?text=" + encodeURIComponent(text);
}

const WA_SVG =
  '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/></svg>';

const ARROW_SVG =
  '<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg>';

/* ============================================================
   DATA LOAD + RENDER
   ============================================================ */
async function loadSite() {
  /* 1) Firestore cloud — 24/7 online source of truth */
  try {
    if (window.fb) {
      const j = await window.fb.getSite();
      if (j.ok && j.site) SITE = j.site;
    }
  } catch (_) {}

  /* 2) Local server fallback (cloud abhi set nahi ho to) */
  if (!SITE) {
    try {
      const r = await fetch("/api/site", { cache: "no-store" });
      const j = await r.json();
      if (j && j.ok && j.site) SITE = j.site;
    } catch (_) {}
  }

  if (!SITE) SITE = FALLBACK_SITE;
  renderSiteData();

  /* 3) LIVE updates — admin change kare to bina refresh turant dikhe */
  if (window.fb && !isDemoPage()) {
    window.fb.watchSite((site) => {
      if (!site) return;
      SITE = site;
      renderSiteData();
      document.querySelectorAll(".reveal").forEach((el) => el.classList.add("visible"));
    });
  }
}

function isDemoPage() {
  return document.body.dataset.demo === "true";
}

function renderSiteData() {
  if (isDemoPage()) return; /* demo pages apna sandbox data khud render karte hain */

  /* Brand (navbar / preloader / footer) */
  const b = SITE.brand || {};
  const fullName = [b.name, b.nameAccent].filter(Boolean).join(" ");
  document.querySelectorAll(".brand-text b").forEach((el) => (el.textContent = fullName));
  document.querySelectorAll(".brand-text small").forEach((el) => (el.textContent = b.tagline || ""));
  document.querySelectorAll(".pre-text").forEach((el) => {
    el.innerHTML = esc(b.name || "") + " <span>" + esc(b.nameAccent || "") + "</span>";
  });
  document.querySelectorAll(".emblem-word").forEach((el) => (el.textContent = fullName));
  document.querySelectorAll(".emblem-tag").forEach((el) => (el.textContent = b.tagline || ""));
  document.querySelectorAll(".hand").forEach((el) => (el.textContent = fullName.split(" ")[0] || ""));

  /* Hero */
  const h = SITE.hero || {};
  const ht = document.getElementById("heroTitle");
  if (ht) ht.innerHTML = esc(h.title || "") + "<br /><span class=\"shine-text\">" + esc(h.titleShine || "") + "</span>";
  const he = document.getElementById("heroEyebrow");
  if (he) he.innerHTML = esc(h.eyebrow || "") + ' <span class="eyebrow-line"></span>';
  const hs = document.getElementById("heroSub");
  if (hs) hs.textContent = h.subtitle || "";

  /* Stats strip */
  const strip = document.getElementById("statsStrip");
  if (strip && Array.isArray(SITE.stats)) {
    strip.innerHTML = SITE.stats
      .map(
        (s) =>
          '<div class="stat2"><b class="shine-text">' +
          esc(s.value) +
          "</b><span>" +
          esc(s.label) +
          "</span></div>"
      )
      .join("");
  }

  /* Services */
  const sg = document.getElementById("servicesGrid");
  if (sg && Array.isArray(SITE.services)) {
    const isPreview = document.body.dataset.servicesPreview === "true";
    const list = isPreview ? SITE.services.slice(0, 6) : SITE.services;
    sg.innerHTML = list
      .map((s) => {
        const icon = s.icon
          ? '<span style="font-size:24px;line-height:1">' + esc(s.icon) + "</span>"
          : '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2 2 7l10 5 10-5-10-5z"/><path d="m2 17 10 5 10-5"/><path d="m2 12 10 5 10-5"/></svg>';
        return (
          '<div class="feature reveal"><div class="feature-icon">' + icon +
          "</div><h3>" + esc(s.title) + "</h3><p>" + esc(s.desc) + "</p></div>"
        );
      })
      .join("");
  }

  /* Projects (portfolio cards — same design as app cards) */
  const pg = document.getElementById("projectsGrid");
  if (pg && Array.isArray(SITE.projects)) {
    const isPreview = document.body.dataset.projectsPreview === "true";
    let list = SITE.projects.slice().sort((a, b) => (a.order || 999) - (b.order || 999));
    if (isPreview) list = list.slice(0, 3);
    pg.innerHTML = list
      .map((p) => {
        const live = String(p.status || "").toUpperCase() === "LIVE";
        const badge = live
          ? '<span class="status-badge live">LIVE</span>'
          : '<span class="status-badge dev">IN DEVELOPMENT</span>';
        const action = live && p.link
          ? '<a class="details-btn details-btn-wide" href="' + esc(p.link) + '" target="_blank" rel="noopener"><span>View Project</span>' + ARROW_SVG + "</a>"
          : '<a class="details-btn details-btn-wide" href="demo-login.html"><span>Ask For Live Demo</span>' + ARROW_SVG + "</a>";
        return (
          '<article class="app-card reveal">' +
          '<div class="app-top"><div class="app-icon">' + (p.icon || "📱") + "</div>" +
          "<div><h3 class=\"app-name\">" + esc(p.name) + '</h3><div class="app-meta"><span class="app-tag">' +
          esc(p.tag || "PROJECT") + "</span>" + badge + "</div></div></div>" +
          '<p class="app-desc">' + esc(p.description || "") + "</p>" +
          '<div class="app-actions">' + action + "</div></article>"
        );
      })
      .join("");
  }

  /* Reviews */
  const rg = document.getElementById("reviewsGrid");
  if (rg && Array.isArray(SITE.reviews)) {
    rg.innerHTML = SITE.reviews
      .map(
        (r) =>
          '<article class="review-card reveal"><div class="review-head">' +
          '<div class="review-avatar">' + esc(String(r.name || "?").charAt(0)) + "</div>" +
          "<div><b>" + esc(r.name) + '</b><div class="stars">' +
          "★".repeat(Math.min(5, r.rating || 5)) + "☆".repeat(5 - Math.min(5, r.rating || 5)) +
          '</div></div><span class="review-app">' + esc(r.project || "") + "</span></div>" +
          "<p>“" + esc(r.text) + "”</p></article>"
      )
      .join("");
  }

  /* WhatsApp / email links */
  document.querySelectorAll("[data-wa]").forEach((a) => {
    a.href = waLink(a.getAttribute("data-wa") || undefined);
    a.target = "_blank";
    a.rel = "noopener";
  });
  document.querySelectorAll(".wa-float").forEach((a) => {
    a.href = waLink();
    a.target = "_blank";
    a.rel = "noopener";
  });
  const waNumText = document.getElementById("waNumberText");
  if (waNumText) waNumText.textContent = "+" + waNumber();
  document.querySelectorAll("[data-email]").forEach((a) => {
    a.href = "mailto:" + (SITE.email || "");
    const t = a.querySelector("[data-email-text]");
    if (t) t.textContent = SITE.email || "";
  });

  /* Contact form submit → server + WhatsApp fallback */
  const form = document.getElementById("contactForm");
  if (form && !form.dataset.bound) {
    form.dataset.bound = "1";
    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      const btn = form.querySelector('button[type="submit"]');
      const name = document.getElementById("cfName").value.trim();
      const email = document.getElementById("cfEmail").value.trim();
      const phone = (document.getElementById("cfPhone") || {}).value || "";
      const msg = document.getElementById("cfMsg").value.trim();
      btn.disabled = true;
      btn.textContent = "Sending...";
      let ok = false;
      try {
        const r = await fetch("/api/contact", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ name, email, phone, message: msg }),
        });
        ok = (await r.json()).ok === true;
      } catch (_) {}
      btn.disabled = false;
      btn.innerHTML = 'Send Message ' + ARROW_SVG;
      const note = document.getElementById("contactNote");
      if (note) {
        note.hidden = false;
        note.textContent = ok
          ? "✓ Message mil gaya! Main jaldi reply karunga — urgent ho to WhatsApp karo."
          : "Message save nahi hua — seedha WhatsApp par bhej do neeche button se.";
      }
      /* Cloud copy — Firestore me (server band ho to bhi safe) */
      if (window.fbSaveMessage) {
        fbSaveMessage({ name, email, phone, message: msg });
      }
      if (ok) {
        window.fbLog && fbLog("contact_form");
        form.reset();
      }
    });
  }

  /* Footer year */
  const yearEl = document.getElementById("year");
  if (yearEl) yearEl.textContent = new Date().getFullYear();
}

/* ============================================================
   SHARED UI (same as original design)
   ============================================================ */

/* ---------- Page Transition (luxury curtain) ---------- */
const pageTransition = document.getElementById("pageTransition");

setTimeout(() => {
  const pre = document.getElementById("preloader");
  pre && pre.classList.add("hidden");
  pageTransition && pageTransition.classList.remove("active");
}, 650);

window.addEventListener("pageshow", (e) => {
  if (e.persisted && pageTransition) pageTransition.classList.remove("active");
});

document.addEventListener("click", (e) => {
  const link = e.target.closest("a");
  if (!link || !pageTransition) return;
  const href = link.getAttribute("href") || "";
  if (
    link.target === "_blank" ||
    href.startsWith("#") ||
    href.startsWith("mailto:") ||
    href.startsWith("tel:") ||
    href.startsWith("javascript:")
  )
    return;
  let url;
  try {
    url = new URL(link.href, window.location.href);
  } catch {
    return;
  }
  if (url.origin !== window.location.origin) return;
  if (url.pathname === window.location.pathname && !url.search) return;
  e.preventDefault();
  pageTransition.classList.add("active");
  setTimeout(() => {
    window.location.href = link.href;
  }, 480);
});

/* ---------- Navbar ---------- */
const navbar = document.getElementById("navbar");
const hamburger = document.getElementById("hamburger");
const navMenu = document.getElementById("navMenu");

window.addEventListener("scroll", () => {
  navbar && navbar.classList.toggle("scrolled", window.scrollY > 40);
  const toTop = document.getElementById("toTop");
  toTop && toTop.classList.toggle("show", window.scrollY > 500);
});

hamburger &&
  hamburger.addEventListener("click", () => {
    hamburger.classList.toggle("open");
    navMenu.classList.toggle("open");
  });

document.querySelectorAll(".nav-menu a").forEach((link) => {
  link.addEventListener("click", () => {
    hamburger && hamburger.classList.remove("open");
    navMenu && navMenu.classList.remove("open");
  });
});

/* ---------- Scroll Reveal ---------- */
const revealObserver = new IntersectionObserver(
  (entries) => {
    entries.forEach((entry, i) => {
      if (entry.isIntersecting) {
        setTimeout(() => entry.target.classList.add("visible"), i * 90);
        revealObserver.unobserve(entry.target);
      }
    });
  },
  { threshold: 0.12 }
);

function observeReveals() {
  document.querySelectorAll(".reveal:not(.visible)").forEach((el) => revealObserver.observe(el));
}

/* ---------- Hero Particles ---------- */
function createParticles() {
  const wrap = document.getElementById("particles");
  if (!wrap) return;
  const count = window.innerWidth < 700 ? 26 : 48;
  for (let i = 0; i < count; i++) {
    const p = document.createElement("span");
    p.className = "particle";
    const size = Math.random() * 3 + 1;
    p.style.width = size + "px";
    p.style.height = size + "px";
    p.style.left = Math.random() * 100 + "%";
    p.style.bottom = "-" + (Math.random() * 30 + 5) + "px";
    p.style.animationDuration = Math.random() * 14 + 9 + "s";
    p.style.animationDelay = Math.random() * 14 + "s";
    p.style.opacity = Math.random() * 0.6 + 0.15;
    wrap.appendChild(p);
  }
}

/* ---------- App Card 3D Tilt ---------- */
function initTilt() {
  const isTouch = window.matchMedia("(hover: none)").matches;
  document.querySelectorAll(".app-card").forEach((card) => {
    if (isTouch) return;
    card.addEventListener("mousemove", (e) => {
      const rect = card.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      const rx = (y / rect.height - 0.5) * -7;
      const ry = (x / rect.width - 0.5) * 7;
      card.style.transform = `perspective(900px) rotateX(${rx}deg) rotateY(${ry}deg) translateY(-4px)`;
      card.style.setProperty("--mx", x + "px");
      card.style.setProperty("--my", y + "px");
    });
    card.addEventListener("mouseleave", () => {
      card.style.transform = "";
    });
  });
}

/* ---------- FAQ Accordion ---------- */
function initFaq() {
  document.querySelectorAll(".faq-q").forEach((btn) => {
    btn.addEventListener("click", () => {
      const item = btn.closest(".faq-item");
      const answer = item.querySelector(".faq-a");
      const isOpen = item.classList.contains("open");
      document.querySelectorAll(".faq-item.open").forEach((openItem) => {
        openItem.classList.remove("open");
        openItem.querySelector(".faq-a").style.maxHeight = null;
      });
      if (!isOpen) {
        item.classList.add("open");
        answer.style.maxHeight = answer.scrollHeight + "px";
      }
    });
  });
}

/* ---------- Back To Top ---------- */
document.getElementById("toTop") &&
  document.getElementById("toTop").addEventListener("click", () =>
    window.scrollTo({ top: 0, behavior: "smooth" })
  );

/* ---------- WhatsApp click tracking (Firebase Analytics) ---------- */
document.addEventListener("click", (e) => {
  const a = e.target.closest && e.target.closest('a[href^="https://wa.me"]');
  if (a) window.fbLog && fbLog("whatsapp_click");
});

/* ---------- Init ---------- */
(async function initSite() {
  await loadSite();
  observeReveals();
  createParticles();
  initTilt();
  initFaq();
})();
