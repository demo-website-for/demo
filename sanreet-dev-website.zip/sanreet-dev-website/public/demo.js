/* ============================================================
   DEMO SYSTEM — Cloud edition (Firestore)
   ------------------------------------------------------------
   demo-admin.html : client apne DEMO STORE ko control karta hai
                     (store info, products, prices, categories)
   demo-site.html  : shopping storefront — panel me save karo →
                     LIVE update (Firestore onSnapshot se)
   Login: sessionStorage me demo session, Firestore se verify.
   3 ghante baad demo khatam — auto logout, ID/Pass band.
   ============================================================ */

/* ---------- Built-in default store (jab tak cloud me seed na ho) ---------- */
const DEFAULT_STORE = {
  kind: "store",
  brand: { name: "AAPKI", nameAccent: "DUKAAN", tagline: "FASHION · ELECTRONICS · HOME" },
  announcement: "★ FREE DELIVERY ON ORDERS ABOVE ₹499 ★ COD AVAILABLE ★ EASY RETURNS ★",
  hero: {
    title: "Sab Kuch,",
    titleShine: "Ek Hi Dukaan Par.",
    subtitle: "Latest fashion, electronics aur ghar ke liye sab kuch — best prices, fast delivery, trusted quality.",
  },
  whatsapp: "918766204904",
  categories: [
    { icon: "👕", title: "Fashion" },
    { icon: "⌚", title: "Watches" },
    { icon: "📱", title: "Electronics" },
    { icon: "🏠", title: "Home" },
  ],
  products: [
    { name: "Running Shoes Pro", icon: "👟", price: 1299, oldPrice: 2499, badge: "SALE", status: "IN STOCK", description: "Ultra-light, comfortable cushioning — daily running aur walk ke liye perfect.", order: 1 },
    { name: "Smart Watch X2", icon: "⌚", price: 1999, oldPrice: 3499, badge: "HOT", status: "IN STOCK", description: "Heart rate, steps, call notifications — 7 din ki battery life.", order: 2 },
    { name: "Wireless Earbuds", icon: "🎧", price: 899, oldPrice: 1799, badge: "SALE", status: "IN STOCK", description: "Deep bass, 24 hour playtime, touch control, IPX5 waterproof.", order: 3 },
    { name: "Cotton T-Shirt", icon: "👕", price: 399, oldPrice: null, badge: "NEW", status: "IN STOCK", description: "100% premium cotton, size M–XXL, 6 colors available.", order: 4 },
    { name: "Leather Wallet", icon: "👛", price: 599, oldPrice: 999, badge: "", status: "IN STOCK", description: "Genuine leather, 6 card slots, RFID protection.", order: 5 },
    { name: "Laptop Backpack 30L", icon: "🎒", price: 1099, oldPrice: 1899, badge: "SALE", status: "OUT OF STOCK", description: "15.6 inch laptop compartment, waterproof, USB charging port.", order: 6 },
  ],
  reviews: [
    { name: "Anjali Sharma", project: "Smart Watch X2", rating: 5, text: "Product quality mast hai! Delivery 2 din me aa gayi, packaging bhi premium thi." },
    { name: "Rohit Kumar", project: "Running Shoes", rating: 5, text: "Price ke hisaab se best shoes. WhatsApp par hi order ho gaya, bilkul aasaan." },
    { name: "Pooja Verma", project: "Wireless Earbuds", rating: 4, text: "Sound quality is great for this price. Battery easily a full day chalti hai." },
  ],
};

/* ---------- Helpers ---------- */
function esc(s) {
  return String(s == null ? "" : s)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function fmtTime(ms) {
  if (ms <= 0) return "00:00:00";
  const s = Math.floor(ms / 1000);
  const h = String(Math.floor(s / 3600)).padStart(2, "0");
  const m = String(Math.floor((s % 3600) / 60)).padStart(2, "0");
  const ss = String(s % 60).padStart(2, "0");
  return h + ":" + m + ":" + ss;
}

function inr(n) {
  const v = Number(n);
  return "₹" + (isFinite(v) ? v : 0).toLocaleString("en-IN");
}

function showToast(msg, isErr) {
  const t = document.getElementById("toast");
  if (!t) return;
  t.textContent = msg;
  t.className = "admin-toast show" + (isErr ? " err" : "");
  clearTimeout(t._h);
  t._h = setTimeout(() => (t.className = "admin-toast"), 2600);
}

function clearDemoSession() {
  sessionStorage.removeItem("sd_demo");
}

function goLoginIfExpired() {
  clearDemoSession();
  location.href = "demo-login.html?expired=1";
}

/* ---------- Session (Firestore se verify hota hai) ---------- */
let DEMO = null; /* {username, passHash, label, expiresAt} */

async function waitForFb() {
  let n = 0;
  while (!window.fb && n++ < 100) await new Promise((r) => setTimeout(r, 50));
  return !!window.fb;
}

async function checkDemoSession() {
  if (!(await waitForFb())) {
    location.href = "demo-login.html";
    return null;
  }
  let s = null;
  try {
    s = JSON.parse(sessionStorage.getItem("sd_demo") || "null");
  } catch (_) {}
  if (!s || !s.username || !s.passHash) {
    location.href = "demo-login.html";
    return null;
  }
  const v = await window.fb.checkDemo(s.username, s.passHash);
  if (v.ok) {
    DEMO = s;
    DEMO.expiresAt = v.expiresAt;
    return DEMO;
  }
  goLoginIfExpired();
  return null;
}

function startCountdown(onExpire) {
  if (!DEMO) return;
  const msLeft = () => (DEMO.expiresAt || 0) - Date.now();
  const chip = document.getElementById("countdown");
  const banner = document.getElementById("demoBanner");
  const bannerTime = document.getElementById("dbTime");

  function tick() {
    const left = msLeft();
    if (chip) {
      chip.textContent = "⏳ " + fmtTime(left);
      chip.classList.toggle("ending", left < 10 * 60 * 1000);
    }
    if (bannerTime) bannerTime.textContent = fmtTime(left);
    if (banner) banner.classList.toggle("ending", left < 10 * 60 * 1000);
    if (left <= 0) {
      clearDemoSession();
      onExpire && onExpire();
      return;
    }
    setTimeout(tick, 1000);
  }
  tick();
}

/* ============================================================
   PAGE DETECT + BOOT
   ============================================================ */
document.addEventListener("DOMContentLoaded", async () => {
  if (document.getElementById("saveBtn")) initDemoAdmin();
  else if (document.getElementById("dbTime")) initDemoSite();
});

/* ============================================================
   DEMO ADMIN PANEL (store control — cloud)
   ============================================================ */
async function initDemoAdmin() {
  const me = await checkDemoSession();
  if (!me) return;
  startCountdown(goLoginIfExpired);

  let STORE = null;
  let STORE_DEFAULT = DEFAULT_STORE;

  async function load() {
    /* store/default doc (agar owner ne cloud me rakha ho) */
    try {
      const d = await window.fb.getStoreDefault();
      if (d.ok && d.store && d.store.products) STORE_DEFAULT = d.store;
    } catch (_) {}

    const j = await window.fb.getSandbox(DEMO.username, STORE_DEFAULT);
    if (j.ok) {
      STORE = j.store && j.store.products ? j.store : JSON.parse(JSON.stringify(DEFAULT_STORE));
      fillForms();
      renderEditors();
    } else {
      showToast(j.error || "Store load nahi hua", true);
    }
  }

  function set(id, v) {
    const el = document.getElementById(id);
    if (el) el.value = v == null ? "" : v;
  }
  function get(id) {
    const el = document.getElementById(id);
    return el ? el.value.trim() : "";
  }

  function fillForms() {
    const b = STORE.brand || {};
    const h = STORE.hero || {};
    set("f_name", b.name);
    set("f_nameAccent", b.nameAccent);
    set("f_tagline", b.tagline);
    set("f_announcement", STORE.announcement);
    set("f_title", h.title);
    set("f_titleShine", h.titleShine);
    set("f_subtitle", h.subtitle);
    set("f_whatsapp", STORE.whatsapp);
  }

  /* ---------- Editors (same UI) ---------- */
  function renderEditors() {
    const pl = document.getElementById("productsList");
    pl.innerHTML = (STORE.products || [])
      .map(
        (p, i) => `
      <div class="admin-row" data-kind="product" data-i="${i}">
        <div class="admin-grid" style="flex:1">
          <div><label class="admin-label">Naam</label><input class="admin-input pj-name" value="${esc(p.name)}" placeholder="Product Name" /></div>
          <div><label class="admin-label">Icon (emoji ya image URL)</label><input class="admin-input pj-icon" value="${esc(p.icon)}" placeholder="👟" /></div>
          <div><label class="admin-label">Price ₹</label><input class="admin-input pj-price" type="number" min="0" value="${esc(p.price)}" /></div>
          <div><label class="admin-label">Old Price ₹ (khaali = no discount)</label><input class="admin-input pj-old" type="number" min="0" value="${p.oldPrice == null ? "" : esc(p.oldPrice)}" /></div>
          <div><label class="admin-label">Badge</label><input class="admin-input pj-badge" value="${esc(p.badge || "")}" placeholder="SALE / HOT / NEW" /></div>
          <div><label class="admin-label">Stock</label>
            <select class="admin-input pj-status">
              <option value="IN STOCK"${String(p.status).toUpperCase() !== "OUT OF STOCK" ? " selected" : ""}>IN STOCK</option>
              <option value="OUT OF STOCK"${String(p.status).toUpperCase() === "OUT OF STOCK" ? " selected" : ""}>OUT OF STOCK</option>
            </select></div>
          <div><label class="admin-label">Order</label><input class="admin-input pj-order" type="number" value="${esc(p.order || i + 1)}" /></div>
          <div class="admin-span-2"><label class="admin-label">Description</label><textarea class="admin-input pj-desc" rows="2">${esc(p.description)}</textarea></div>
        </div>
        <div class="admin-row-btns"><button class="admin-mini danger" data-del title="Delete">✕</button></div>
      </div>`
      )
      .join("");

    const cl = document.getElementById("catsList");
    cl.innerHTML = (STORE.categories || [])
      .map(
        (c, i) => `
      <div class="admin-row" data-kind="cat" data-i="${i}">
        <div class="admin-grid" style="flex:1">
          <div><label class="admin-label">Icon (emoji)</label><input class="admin-input ct-icon" value="${esc(c.icon)}" placeholder="👕" /></div>
          <div><label class="admin-label">Category Naam</label><input class="admin-input ct-title" value="${esc(c.title)}" placeholder="Fashion" /></div>
        </div>
        <div class="admin-row-btns"><button class="admin-mini danger" data-del title="Delete">✕</button></div>
      </div>`
      )
      .join("");

    const rl = document.getElementById("reviewsList");
    rl.innerHTML = (STORE.reviews || [])
      .map(
        (r, i) => `
      <div class="admin-row" data-kind="review" data-i="${i}">
        <div class="admin-grid" style="flex:1">
          <div><label class="admin-label">Customer Ka Naam</label><input class="admin-input rv-name" value="${esc(r.name)}" /></div>
          <div><label class="admin-label">Kaunsa Product</label><input class="admin-input rv-project" value="${esc(r.project)}" /></div>
          <div><label class="admin-label">Rating</label>
            <select class="admin-input rv-rating">
              ${[5, 4, 3, 2, 1].map((n) => `<option value="${n}"${(r.rating || 5) === n ? " selected" : ""}>${"★".repeat(n)}${"☆".repeat(5 - n)} (${n})</option>`).join("")}
            </select></div>
          <div class="admin-span-2"><label class="admin-label">Review</label><textarea class="admin-input rv-text" rows="2">${esc(r.text)}</textarea></div>
        </div>
        <div class="admin-row-btns"><button class="admin-mini danger" data-del title="Delete">✕</button></div>
      </div>`
      )
      .join("");

    pl.querySelectorAll("[data-del]").forEach((b) =>
      b.addEventListener("click", () => {
        STORE.products.splice(Number(b.closest("[data-i]").dataset.i), 1);
        renderEditors();
      })
    );
    cl.querySelectorAll("[data-del]").forEach((b) =>
      b.addEventListener("click", () => {
        STORE.categories.splice(Number(b.closest("[data-i]").dataset.i), 1);
        renderEditors();
      })
    );
    rl.querySelectorAll("[data-del]").forEach((b) =>
      b.addEventListener("click", () => {
        STORE.reviews.splice(Number(b.closest("[data-i]").dataset.i), 1);
        renderEditors();
      })
    );
  }

  function rowVal(row, cls) {
    const el = row.querySelector(cls);
    return el ? el.value : "";
  }

  function collect() {
    STORE.brand = {
      name: get("f_name") || "MY",
      nameAccent: get("f_nameAccent") || "STORE",
      tagline: get("f_tagline"),
    };
    STORE.announcement = get("f_announcement");
    STORE.hero = {
      title: get("f_title"),
      titleShine: get("f_titleShine"),
      subtitle: get("f_subtitle"),
    };
    STORE.whatsapp = get("f_whatsapp").replace(/[^0-9+]/g, "");
    STORE.kind = "store";

    STORE.products = [...document.querySelectorAll('#productsList [data-kind="product"]')].map((row, i) => {
      const oldRaw = rowVal(row, ".pj-old");
      return {
        name: rowVal(row, ".pj-name") || "Product",
        icon: rowVal(row, ".pj-icon") || "🛍️",
        price: Math.max(0, Number(rowVal(row, ".pj-price")) || 0),
        oldPrice: oldRaw === "" ? null : Math.max(0, Number(oldRaw) || 0),
        badge: rowVal(row, ".pj-badge"),
        status: rowVal(row, ".pj-status"),
        order: Number(rowVal(row, ".pj-order")) || i + 1,
        description: rowVal(row, ".pj-desc"),
      };
    });

    STORE.categories = [...document.querySelectorAll('#catsList [data-kind="cat"]')].map((row) => ({
      icon: rowVal(row, ".ct-icon") || "🏷️",
      title: rowVal(row, ".ct-title") || "Category",
    }));

    STORE.reviews = [...document.querySelectorAll('#reviewsList [data-kind="review"]')].map((row) => ({
      name: rowVal(row, ".rv-name") || "Customer",
      project: rowVal(row, ".rv-project"),
      rating: Number(rowVal(row, ".rv-rating")) || 5,
      text: rowVal(row, ".rv-text"),
    }));
  }

  async function save() {
    collect();
    const btns = [document.getElementById("saveBtn"), document.getElementById("saveBtn2"), document.getElementById("saveBtn3")];
    btns.forEach((b) => b && (b.disabled = true));
    const j = await window.fb.saveSandbox(DEMO.username, STORE);
    if (j.ok) showToast("✓ Save ho gaya! 🛒 Store tab me LIVE dikhega.");
    else showToast(j.error || "Save fail hua", true);
    btns.forEach((b) => b && (b.disabled = false));
  }

  /* Wire up */
  document.getElementById("saveBtn").addEventListener("click", save);
  document.getElementById("saveBtn2").addEventListener("click", save);
  document.getElementById("saveBtn3").addEventListener("click", save);

  document.getElementById("addProductBtn").addEventListener("click", () => {
    collect();
    STORE.products.push({
      name: "Naya Product",
      icon: "🛍️",
      price: 499,
      oldPrice: null,
      badge: "NEW",
      status: "IN STOCK",
      order: STORE.products.length + 1,
      description: "Product ka description yahan likho.",
    });
    renderEditors();
  });

  document.getElementById("addCatBtn").addEventListener("click", () => {
    collect();
    STORE.categories.push({ icon: "🏷️", title: "New Category" });
    renderEditors();
  });

  document.getElementById("addReviewBtn").addEventListener("click", () => {
    collect();
    STORE.reviews.push({ name: "Customer", project: "Product", rating: 5, text: "Review yahan likho." });
    renderEditors();
  });

  document.getElementById("resetBtn").addEventListener("click", async () => {
    if (!confirm("Store wapas original products par reset kar do?")) return;
    const j = await window.fb.resetDemoSandbox(DEMO.username, STORE_DEFAULT);
    if (j.ok) {
      showToast("✓ Reset ho gaya");
      load();
    } else showToast(j.error || "Reset fail", true);
  });

  document.getElementById("logoutBtn").addEventListener("click", () => {
    clearDemoSession();
    location.href = "demo-login.html";
  });

  /* Tabs */
  document.querySelectorAll(".admin-tab").forEach((tab) => {
    tab.addEventListener("click", () => {
      document.querySelectorAll(".admin-tab").forEach((t) => t.classList.remove("active"));
      document.querySelectorAll(".admin-panel").forEach((p) => p.classList.remove("active"));
      tab.classList.add("active");
      const panel = document.getElementById("tab-" + tab.dataset.tab);
      panel && panel.classList.add("active");
    });
  });

  load();
}

/* ============================================================
   DEMO STORE (shopping website — sandbox se, LIVE updates)
   ============================================================ */
const WA_SVG =
  '<svg viewBox="0 0 24 24"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/></svg>';

async function initDemoSite() {
  const me = await checkDemoSession();
  if (!me) return;
  startCountdown(goLoginIfExpired);

  const CART_KEY = "sd_demo_cart_" + DEMO.username;
  let STORE = null;
  let cart = loadCart();

  function loadCart() {
    try {
      return JSON.parse(localStorage.getItem(CART_KEY) || "[]");
    } catch (_) {
      return [];
    }
  }
  function saveCart() {
    localStorage.setItem(CART_KEY, JSON.stringify(cart));
  }

  function findProduct(idx) {
    return (STORE && STORE.products ? STORE.products : [])[idx];
  }

  /* ---------- RENDER STORE ---------- */
  function renderStore(S) {
    const b = S.brand || {};
    const h = S.hero || {};
    const fullName = [b.name, b.nameAccent].filter(Boolean).join(" ") || "My Store";

    document.querySelectorAll(".brand-text b").forEach((el) => (el.textContent = fullName));
    document.querySelectorAll(".brand-text small").forEach((el) => (el.textContent = b.tagline || ""));
    document.querySelectorAll(".emblem-word").forEach((el) => (el.textContent = fullName));
    document.querySelectorAll(".emblem-tag").forEach((el) => (el.textContent = b.tagline || ""));
    document.title = fullName + " — Online Store";

    const ab = document.getElementById("announceBar");
    if (ab) ab.textContent = S.announcement || "";

    const he = document.getElementById("heroEyebrow");
    if (he) he.innerHTML = "WELCOME TO " + esc(fullName) + ' <span class="eyebrow-line"></span>';
    const ht = document.getElementById("heroTitle");
    if (ht) ht.innerHTML = esc(h.title || "") + "<br /><span class=\"shine-text\">" + esc(h.titleShine || "") + "</span>";
    const hs = document.getElementById("heroSub");
    if (hs) hs.textContent = h.subtitle || "";

    const chips = document.getElementById("catChips");
    if (chips) {
      chips.innerHTML = (S.categories || [])
        .map(
          (c) =>
            '<span class="cat-chip"><span class="ci">' + esc(c.icon || "🏷️") + "</span>" + esc(c.title) + "</span>"
        )
        .join("");
    }

    const pg = document.getElementById("productGrid");
    if (pg) {
      const list = (S.products || []).slice().sort((a, b2) => (a.order || 999) - (b2.order || 999));
      pg.innerHTML = list
        .map((p, idx) => {
          const out = String(p.status || "").toUpperCase() === "OUT OF STOCK";
          const badgeCls = String(p.badge || "").toUpperCase();
          const badge = p.badge
            ? '<span class="p-badge' +
              (badgeCls === "HOT" ? " hot" : badgeCls === "NEW" ? " new" : "") +
              '">' +
              esc(p.badge) +
              "</span>"
            : "";
          const stock = out
            ? '<span class="p-stock out">Out Of Stock</span>'
            : '<span class="p-stock in">In Stock</span>';
          const old =
            p.oldPrice && Number(p.oldPrice) > Number(p.price)
              ? '<span class="p-oldprice">' + inr(p.oldPrice) + "</span>" +
                '<span class="p-off">-' +
                Math.round(((Number(p.oldPrice) - Number(p.price)) / Number(p.oldPrice)) * 100) +
                "%</span>"
              : "";
          const img = String(p.icon || "").startsWith("http")
            ? '<img src="' + esc(p.icon) + '" alt="' + esc(p.name) + '" loading="lazy" />'
            : esc(p.icon || "🛍️");
          const addBtn = out
            ? '<button class="p-add" disabled>Out Of Stock</button>'
            : '<button class="p-add" data-add="' + idx + '">Add To Cart <span>＋</span></button>';
          return (
            '<article class="p-card reveal">' +
            '<div class="p-thumb">' + img + badge + stock + "</div>" +
            '<div class="p-body">' +
            '<h3 class="p-name">' + esc(p.name) + "</h3>" +
            '<p class="p-desc">' + esc(p.description || "") + "</p>" +
            '<div class="p-price-row"><span class="p-price">' + inr(p.price) + "</span>" + old + "</div>" +
            '<div class="p-actions">' + addBtn +
            '<a class="p-wa" data-pwa="' + idx + '" href="#" aria-label="WhatsApp par order karo">' + WA_SVG + "</a>" +
            "</div></div></article>"
          );
        })
        .join("");

      pg.querySelectorAll("[data-add]").forEach((btn) =>
        btn.addEventListener("click", () => addToCart(Number(btn.dataset.add), btn))
      );
      pg.querySelectorAll("[data-pwa]").forEach((a) =>
        a.addEventListener("click", (e) => {
          e.preventDefault();
          const p = findProduct(Number(a.dataset.pwa));
          if (p) {
            const msg =
              "Namaste! Mujhe ye product order karna hai:\n\n🛍️ " + p.name + " — " + inr(p.price) + "\n\nKya ye available hai?";
            window.open("https://wa.me/" + String(S.whatsapp || "").replace(/[^0-9]/g, "") + "?text=" + encodeURIComponent(msg), "_blank");
          }
        })
      );
    }

    const rg = document.getElementById("reviewsGrid");
    if (rg && Array.isArray(S.reviews)) {
      rg.innerHTML = S.reviews
        .map(
          (r) =>
            '<article class="review-card reveal"><div class="review-head">' +
            '<div class="review-avatar">' + esc(String(r.name || "?").charAt(0)) + "</div>" +
            "<div><b>" + esc(r.name) + '</b><div class="stars">' +
            "★".repeat(Math.min(5, r.rating || 5)) + "☆".repeat(5 - Math.min(5, r.rating || 5)) +
            '</div></div><span class="review-app">' + esc(r.project || "") + "</span></div>" +
            "<p>“" + esc(r.text) + "”</p></article>"
        )
        .join("");
    }

    const n = String(S.whatsapp || "").replace(/[^0-9]/g, "");
    document.querySelectorAll("[data-wa]").forEach((a) => {
      a.href = "https://wa.me/" + n + "?text=" + encodeURIComponent("Namaste! Mujhe aapke store ke baare me jaankari chahiye.");
      a.target = "_blank";
      a.rel = "noopener";
    });

    const yearEl = document.getElementById("year");
    if (yearEl) yearEl.textContent = new Date().getFullYear();
  }

  /* ---------- CART ---------- */
  function cartCount() {
    return cart.reduce((s, it) => s + it.qty, 0);
  }
  function cartTotal() {
    return cart.reduce((s, it) => {
      const p = findProduct(it.idx);
      return s + (p ? p.price * it.qty : 0);
    }, 0);
  }

  function addToCart(idx, btn) {
    const p = findProduct(idx);
    if (!p) return;
    const found = cart.find((it) => it.idx === idx);
    if (found) found.qty += 1;
    else cart.push({ idx, qty: 1 });
    saveCart();
    renderCart();
    if (btn) {
      btn.classList.add("added");
      const old = btn.innerHTML;
      btn.innerHTML = "✓ Cart Me Daala";
      setTimeout(() => {
        btn.classList.remove("added");
        btn.innerHTML = old;
      }, 1100);
    }
  }

  function renderCart() {
    const count = cartCount();
    [document.getElementById("cartCount"), document.getElementById("cartCountFloat")].forEach((el) => {
      if (!el) return;
      el.textContent = count;
      el.dataset.zero = count === 0 ? "1" : "0";
    });

    const wrap = document.getElementById("cartItems");
    if (!wrap) return;
    if (!cart.length) {
      wrap.innerHTML = '<div class="cart-empty">Cart khaali hai — products me se kuch add karo!</div>';
    } else {
      wrap.innerHTML = cart
        .map((it, i) => {
          const p = findProduct(it.idx);
          if (!p) return "";
          const iconHTML = String(p.icon || "").startsWith("http")
            ? '<img src="' + esc(p.icon) + '" alt="" />'
            : esc(p.icon || "🛍️");
          return (
            '<div class="cart-item">' +
            '<div class="ci-icon">' + iconHTML + "</div>" +
            '<div class="ci-main"><b>' + esc(p.name) + '</b><div class="ci-price">' + inr(p.price) + " × " + it.qty + " = " + inr(p.price * it.qty) + "</div></div>" +
            '<div class="ci-qty"><button data-dec="' + i + '">−</button><span>' + it.qty + '</span><button data-inc="' + i + '">+</button></div>' +
            '<button class="ci-del" data-delcart="' + i + '">✕</button>' +
            "</div>"
          );
        })
        .join("");

      wrap.querySelectorAll("[data-inc]").forEach((b) =>
        b.addEventListener("click", () => {
          cart[Number(b.dataset.inc)].qty += 1;
          saveCart();
          renderCart();
        })
      );
      wrap.querySelectorAll("[data-dec]").forEach((b) =>
        b.addEventListener("click", () => {
          const it = cart[Number(b.dataset.dec)];
          it.qty -= 1;
          if (it.qty <= 0) cart.splice(Number(b.dataset.dec), 1);
          saveCart();
          renderCart();
        })
      );
      wrap.querySelectorAll("[data-delcart]").forEach((b) =>
        b.addEventListener("click", () => {
          cart.splice(Number(b.dataset.delcart), 1);
          saveCart();
          renderCart();
        })
      );
    }

    document.getElementById("cartTotal").textContent = inr(cartTotal());

    const orderBtn = document.getElementById("cartOrderBtn");
    if (orderBtn) {
      if (!cart.length) {
        orderBtn.style.opacity = "0.5";
        orderBtn.style.pointerEvents = "none";
      } else {
        orderBtn.style.opacity = "1";
        orderBtn.style.pointerEvents = "auto";
        const lines = cart
          .map((it, i) => {
            const p = findProduct(it.idx);
            return p ? i + 1 + ". " + p.name + " × " + it.qty + " = " + inr(p.price * it.qty) : "";
          })
          .filter(Boolean);
        const msg =
          "Namaste! Mujhe ye order karna hai:\n\n" +
          lines.join("\n") +
          "\n\n💰 Total: " + inr(cartTotal()) +
          "\n\nNaam: \nAddress: ";
        const n = String((STORE && STORE.whatsapp) || "").replace(/[^0-9]/g, "");
        orderBtn.href = "https://wa.me/" + n + "?text=" + encodeURIComponent(msg);
        orderBtn.target = "_blank";
      }
    }
  }

  /* Cart open/close */
  const drawer = document.getElementById("cartDrawer");
  const overlay = document.getElementById("cartOverlay");
  function openCart() {
    drawer && drawer.classList.add("open");
    overlay && overlay.classList.add("open");
  }
  function closeCart() {
    drawer && drawer.classList.remove("open");
    overlay && overlay.classList.remove("open");
  }
  ["cartOpenBtn", "cartFloatBtn"].forEach((id) => {
    const el = document.getElementById(id);
    el && el.addEventListener("click", openCart);
  });
  const closeBtn = document.getElementById("cartCloseBtn");
  closeBtn && closeBtn.addEventListener("click", closeCart);
  overlay && overlay.addEventListener("click", closeCart);

  /* ---------- LOAD + LIVE (onSnapshot — cloud se turant) ---------- */
  async function loadAndWatch() {
    let def = DEFAULT_STORE;
    try {
      const d = await window.fb.getStoreDefault();
      if (d.ok && d.store && d.store.products) def = d.store;
    } catch (_) {}

    const j = await window.fb.getSandbox(DEMO.username, def);
    if (!j.ok) {
      showToast("Store load nahi hua", true);
      return;
    }
    STORE = j.store;
    renderStore(STORE);
    renderCart();
    document.querySelectorAll(".reveal").forEach((el) => el.classList.add("visible"));

    /* LIVE: control panel me save → yahan instantly (bina refresh) */
    window.fb.watchSandbox(DEMO.username, (store) => {
      if (!store || !store.products) return;
      STORE = store;
      renderStore(STORE);
      renderCart();
      document.querySelectorAll(".reveal").forEach((el) => el.classList.add("visible"));
    });
  }

  await loadAndWatch();
}
