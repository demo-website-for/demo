/* ============================================================
   OWNER PANEL — Cloud edition (Firebase Auth + Firestore)
   ------------------------------------------------------------
   - Login: Firebase account se (jo aapne console me banaya)
   - Demo accounts, site content, messages SAB cloud me
   - Cloud me change karo → poori duniya ko turant dikhta hai
   One-time setup: FIREBASE-SETUP.txt
   ============================================================ */

/* ---------- Built-in defaults (pehli baar cloud me seed hote hain) ---------- */
const DEFAULT_SITE = {
  brand: { name: "COSMIC", nameAccent: "STORE", tagline: "APPS. WEBSITES. DELIVERED." },
  hero: {
    eyebrow: "INDIVIDUAL APP & WEBSITE DEVELOPER",
    title: "Your Idea,",
    titleShine: "Built For Real.",
    subtitle: "I design and develop mobile apps, websites and admin panels for growing businesses — premium design, fast delivery, honest pricing.",
  },
  stats: [
    { value: "25+", label: "Projects Built" },
    { value: "3h", label: "Free Live Demo" },
    { value: "100%", label: "Custom Work" },
    { value: "24/7", label: "Support" },
  ],
  whatsapp: "918766204904",
  email: "hello@example.com",
  services: [
    { icon: "📱", title: "Mobile App Development", desc: "Android apps with modern UI — from your idea to Play Store launch." },
    { icon: "💻", title: "Website Development", desc: "Fast, beautiful business websites that look premium on every device." },
    { icon: "🛠️", title: "Admin Panels", desc: "Control your whole website — content, products, orders — from one panel." },
    { icon: "🛒", title: "E-Commerce Stores", desc: "Complete online store with products, cart and payment setup." },
    { icon: "🎨", title: "UI / UX Design", desc: "Clean, premium designs your customers will love at first sight." },
    { icon: "🔧", title: "Maintenance & Support", desc: "Updates, fixes and improvements — your website stays healthy." },
  ],
  projects: [
    { name: "ShopKart — Online Store", icon: "🛍️", tag: "E-COMMERCE", status: "LIVE", link: "", description: "Complete e-commerce store with admin panel, product manager and order tracking.", order: 1 },
    { name: "FitTrack — Fitness App", icon: "💪", tag: "ANDROID APP", status: "LIVE", link: "", description: "Workout planner with streaks, charts and reminders. Built for daily use.", order: 2 },
    { name: "GlowSalon — Booking Website", icon: "💅", tag: "BUSINESS", status: "LIVE", link: "", description: "Salon website with online appointment booking and WhatsApp alerts.", order: 3 },
    { name: "FoodDash — Delivery App", icon: "🍔", tag: "ANDROID APP", status: "IN DEVELOPMENT", link: "", description: "Food ordering app with live menu control from a powerful admin panel.", order: 4 },
  ],
  reviews: [
    { name: "Rahul Mehta", project: "ShopKart", rating: 5, text: "Meri dukaan ab online hai! Admin panel se khud products add karta hoon. Kaam bohot clean kiya hai." },
    { name: "Priya Sharma", project: "GlowSalon", rating: 5, text: "Website 5 din me ready mili aur bilkul waisi hai jaisi chahiye thi. Bookings badh gayi hain!" },
    { name: "Amit Verma", project: "FitTrack", rating: 5, text: "App smooth chalti hai, design premium lagta hai. Support bhi fast milta hai. Highly recommended." },
  ],
};

const DEFAULT_STORE = {
  kind: "store",
  brand: { name: "AAPKI", nameAccent: "DUKAAN", tagline: "FASHION · ELECTRONICS · HOME" },
  announcement: "★ FREE DELIVERY ON ORDERS ABOVE ₹499 ★ COD AVAILABLE ★ EASY RETURNS ★",
  hero: {
    title: "Sab Kuch,",
    titleShine: "Ek Hi Dukaan Par.",
    subtitle: "Latest fashion, electronics aur ghar ke liye sab kuch — best prices, fast delivery, trusted quality.",
  },
  whatsapp: "918766204904",
  categories: [
    { icon: "👕", title: "Fashion" },
    { icon: "⌚", title: "Watches" },
    { icon: "📱", title: "Electronics" },
    { icon: "🏠", title: "Home" },
  ],
  products: [
    { name: "Running Shoes Pro", icon: "👟", price: 1299, oldPrice: 2499, badge: "SALE", status: "IN STOCK", description: "Ultra-light, comfortable cushioning — daily running aur walk ke liye perfect.", order: 1 },
    { name: "Smart Watch X2", icon: "⌚", price: 1999, oldPrice: 3499, badge: "HOT", status: "IN STOCK", description: "Heart rate, steps, call notifications — 7 din ki battery life.", order: 2 },
    { name: "Wireless Earbuds", icon: "🎧", price: 899, oldPrice: 1799, badge: "SALE", status: "IN STOCK", description: "Deep bass, 24 hour playtime, touch control, IPX5 waterproof.", order: 3 },
    { name: "Cotton T-Shirt", icon: "👕", price: 399, oldPrice: null, badge: "NEW", status: "IN STOCK", description: "100% premium cotton, size M–XXL, 6 colors available.", order: 4 },
    { name: "Leather Wallet", icon: "👛", price: 599, oldPrice: 999, badge: "", status: "IN STOCK", description: "Genuine leather, 6 card slots, RFID protection.", order: 5 },
    { name: "Laptop Backpack 30L", icon: "🎒", price: 1099, oldPrice: 1899, badge: "SALE", status: "OUT OF STOCK", description: "15.6 inch laptop compartment, waterproof, USB charging port.", order: 6 },
  ],
  reviews: [
    { name: "Anjali Sharma", project: "Smart Watch X2", rating: 5, text: "Product quality mast hai! Delivery 2 din me aa gayi, packaging bhi premium thi." },
    { name: "Rohit Kumar", project: "Running Shoes", rating: 5, text: "Price ke hisaab se best shoes. WhatsApp par hi order ho gaya, bilkul aasaan." },
    { name: "Pooja Verma", project: "Wireless Earbuds", rating: 4, text: "Sound quality is great for this price. Battery easily a full day chalti hai." },
  ],
};

/* ---------- Helpers ---------- */
function esc(s) {
  return String(s == null ? "" : s)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function fmtLeft(ms) {
  if (ms <= 0) return "expired";
  const s = Math.floor(ms / 1000);
  const d = Math.floor(s / 86400);
  const h = String(Math.floor((s % 86400) / 3600)).padStart(2, "0");
  const m = String(Math.floor((s % 3600) / 60)).padStart(2, "0");
  return (d > 0 ? d + "d " : "") + h + ":" + m;
}

function fmtDate(ts) {
  if (!ts) return "—";
  const d = new Date(ts);
  return d.toLocaleDateString() + " " + d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

function showToast(msg, isErr) {
  const t = document.getElementById("toast");
  t.textContent = msg;
  t.className = "admin-toast show" + (isErr ? " err" : "");
  clearTimeout(t._h);
  t._h = setTimeout(() => (t.className = "admin-toast"), 3000);
}

async function waitForFb() {
  let n = 0;
  while (!window.fb && n++ < 100) await new Promise((r) => setTimeout(r, 50));
  return !!window.fb;
}

/* ============================================================
   VIEWS
   ============================================================ */
const loginView = document.getElementById("loginView");
const adminView = document.getElementById("adminView");

function showLogin() {
  loginView.hidden = false;
  adminView.hidden = true;
}

function showAdmin() {
  loginView.hidden = true;
  adminView.hidden = false;
  refreshAll();
}

/* ============================================================
   LOGIN (Firebase Auth — email/password)
   ============================================================ */
document.getElementById("loginForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const err = document.getElementById("loginError");
  err.hidden = true;
  if (!(await waitForFb())) {
    err.textContent = "Firebase load nahi hua — internet check karo.";
    err.hidden = false;
    return;
  }
  const j = await window.fb.ownerLogin(
    document.getElementById("ownerUser").value.trim(),
    document.getElementById("ownerPass").value
  );
  if (j.ok) {
    showAdmin();
    return;
  }
  err.textContent = j.error;
  if ((j.error || "").toLowerCase().includes("galat email")) {
    err.textContent = "Galat email ya password. (Owner account Firebase console me banta hai — FIREBASE-SETUP.txt Step 3 dekho.)";
  }
  err.hidden = false;
});

document.getElementById("logoutBtn").addEventListener("click", async () => {
  await window.fb.ownerLogout();
});

/* Auth state — login/logout dono yahin se chalta hai */
(async function () {
  if (!(await waitForFb())) return;
  window.fb.onOwner(async (email) => {
    if (email) {
      document.getElementById("loginError").hidden = true;
      showAdmin();
    } else {
      showLogin();
    }
  });
})();

/* ============================================================
   TABS
   ============================================================ */
document.querySelectorAll(".admin-tab").forEach((tab) => {
  tab.addEventListener("click", () => activateTab(tab.dataset.tab));
});

function activateTab(name) {
  document.querySelectorAll(".admin-tab").forEach((t) => t.classList.toggle("active", t.dataset.tab === name));
  document.querySelectorAll(".admin-panel").forEach((p) => p.classList.remove("active"));
  const panel = document.getElementById("tab-" + name);
  if (panel) panel.classList.add("active");
}

document.getElementById("gotoContent").addEventListener("click", () => activateTab("content"));
document.getElementById("gotoMessages").addEventListener("click", () => activateTab("messages"));
document.getElementById("quickDemoBtn").addEventListener("click", () => {
  activateTab("demos");
  document.getElementById("demoPin").focus();
});

/* ============================================================
   DEMO ACCOUNTS
   ============================================================ */
document.getElementById("createDemoBtn").addEventListener("click", createDemo);

function randomUsername() {
  const chars = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";
  let s = "";
  for (let i = 0; i < 4; i++) s += chars[Math.floor(Math.random() * chars.length)];
  return "demo" + s;
}

function randomPassword() {
  const chars = "abcdefghjkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ23456789";
  let p = "";
  for (let i = 0; i < 8; i++) p += chars[Math.floor(Math.random() * chars.length)];
  return p;
}

async function createDemo() {
  const btn = document.getElementById("createDemoBtn");
  const pin = document.getElementById("demoPin").value.trim();
  if (!pin) {
    showToast("Pehle security PIN daalo 🔒", true);
    document.getElementById("demoPin").focus();
    return;
  }
  btn.disabled = true;
  btn.textContent = "Ban raha hai...";
  const username = randomUsername();
  const password = randomPassword();
  const j = await window.fb.createDemo({
    username,
    pass: password,
    label: document.getElementById("demoLabel").value.trim(),
    hours: parseFloat(document.getElementById("demoHours").value),
    pin,
  });
  if (j.ok) {
    const box = document.getElementById("credBox");
    box.hidden = false;
    document.getElementById("credUser").textContent = username;
    document.getElementById("credPass").textContent = password;
    document.getElementById("credLink").textContent = location.origin + "/demo-login.html";
    box.scrollIntoView({ behavior: "smooth", block: "center" });
    showToast("✓ Demo ban gaya! ID/Pass copy karke bhej do.");
    loadDemos();
  } else {
    showToast(j.error || "Demo nahi bana", true);
  }
  btn.disabled = false;
  btn.textContent = "Demo ID/Pass Banao";
}

/* Copy buttons */
document.querySelectorAll(".copy-btn").forEach((b) => {
  b.addEventListener("click", async () => {
    const src = document.getElementById(b.dataset.copy);
    const text = src ? src.textContent : "";
    try {
      await navigator.clipboard.writeText(text);
    } catch (_) {
      const ta = document.createElement("textarea");
      ta.value = text;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      ta.remove();
    }
    b.textContent = "✓ Copied";
    b.classList.add("done");
    setTimeout(() => {
      b.textContent = "Copy";
      b.classList.remove("done");
    }, 1500);
  });
});

let DEMOS = [];

async function loadDemos() {
  const j = await window.fb.listDemos();
  if (j.ok) {
    DEMOS = j.demos;
    renderDemos();
  } else if (j.error) {
    const list = document.getElementById("demosList");
    if (list) list.innerHTML = '<div class="admin-empty">⚠ ' + esc(j.error) + "</div>";
  }
}

function renderDemos() {
  const list = document.getElementById("demosList");
  if (!DEMOS.length) {
    list.innerHTML = '<div class="admin-empty">Abhi koi demo nahi bana. Upar se pehla demo banao 🎟</div>';
    return;
  }
  const now = Date.now();
  list.innerHTML = DEMOS.map((d) => {
    const active = (d.expiresAt || 0) > now;
    return `
    <div class="admin-row">
      <div class="admin-row-icon" style="font-size:20px">🎟</div>
      <div class="admin-row-main">
        <b class="mono">${esc(d.username)}</b>
        <span>${esc(d.label || "No label")} · Banaya: ${fmtDate(d.createdAt)}</span>
        <div class="row-sub">${
          active ? "Time bacha: <b>" + fmtLeft(d.expiresAt - now) + "</b>" : "Ye demo khatam ho gaya"
        }</div>
      </div>
      <div class="admin-row-btns">
        <span class="badge ${active ? "active" : "expired"}">${active ? "Active" : "Expired"}</span>
        <button class="admin-mini" data-ext="${esc(d.username)}" title="3 ghante aur do">+3h</button>
        <button class="admin-mini" data-reset="${esc(d.username)}" title="Demo store reset karo">Reset</button>
        <button class="admin-mini danger" data-del="${esc(d.username)}">Delete</button>
      </div>
    </div>`;
  }).join("");

  list.querySelectorAll("[data-ext]").forEach((b) =>
    b.addEventListener("click", async () => {
      const j = await window.fb.extendDemo(b.dataset.ext, 3);
      if (j.ok) {
        showToast("✓ " + b.dataset.ext + " ko 3 ghante aur mil gaye");
        loadDemos();
      } else showToast(j.error || "Extend nahi hua", true);
    })
  );
  list.querySelectorAll("[data-reset]").forEach((b) =>
    b.addEventListener("click", async () => {
      const j = await window.fb.resetDemoSandbox(b.dataset.reset, DEFAULT_STORE);
      if (j.ok) showToast("✓ Demo store reset ho gaya");
      else showToast(j.error || "Reset nahi hua", true);
    })
  );
  list.querySelectorAll("[data-del]").forEach((b) =>
    b.addEventListener("click", async () => {
      if (!confirm(b.dataset.del + " demo delete kar do?")) return;
      const j = await window.fb.deleteDemo(b.dataset.del);
      if (j.ok) {
        showToast("✓ Demo delete ho gaya");
        loadDemos();
      }
    })
  );
}

/* ============================================================
   SITE CONTENT (portfolio — cloud me save hota hai)
   ============================================================ */
let SITE = null;

async function loadSite() {
  const j = await window.fb.getSite();
  if (j.ok && j.site) {
    SITE = j.site;
  } else {
    SITE = JSON.parse(JSON.stringify(DEFAULT_SITE));
    /* pehli baar — defaults cloud me seed karo */
    await window.fb.saveSite(SITE);
  }
  fillContentForms();
}

function setVal(id, v) {
  const el = document.getElementById(id);
  if (el) el.value = v == null ? "" : v;
}

function fillContentForms() {
  const b = SITE.brand || {};
  const h = SITE.hero || {};
  setVal("f_name", b.name);
  setVal("f_nameAccent", b.nameAccent);
  setVal("f_tagline", b.tagline);
  setVal("f_eyebrow", h.eyebrow);
  setVal("f_title", h.title);
  setVal("f_titleShine", h.titleShine);
  setVal("f_subtitle", h.subtitle);
  setVal("f_whatsapp", SITE.whatsapp);
  setVal("f_email", SITE.email);

  const statVals = document.querySelectorAll("#tab-content .st-value");
  const statLabels = document.querySelectorAll("#tab-content .st-label");
  for (let i = 0; i < 4; i++) {
    const s = (SITE.stats || [])[i] || { value: "", label: "" };
    if (statVals[i]) statVals[i].value = s.value || "";
    if (statLabels[i]) statLabels[i].value = s.label || "";
  }

  renderEditors();
}

function renderEditors() {
  const sl = document.getElementById("servicesList");
  sl.innerHTML = (SITE.services || [])
    .map(
      (s, i) => `
    <div class="admin-row" data-kind="service" data-i="${i}">
      <div class="admin-grid" style="flex:1">
        <div><label class="admin-label">Icon (emoji)</label><input class="admin-input sv-icon" value="${esc(s.icon)}" placeholder="📱" /></div>
        <div><label class="admin-label">Title</label><input class="admin-input sv-title" value="${esc(s.title)}" /></div>
        <div class="admin-span-2"><label class="admin-label">Description</label><textarea class="admin-input sv-desc" rows="2">${esc(s.desc)}</textarea></div>
      </div>
      <div class="admin-row-btns"><button class="admin-mini danger" data-del title="Delete">✕</button></div>
    </div>`
    )
    .join("");

  const pl = document.getElementById("projectsList");
  pl.innerHTML = (SITE.projects || [])
    .map(
      (p, i) => `
    <div class="admin-row" data-kind="project" data-i="${i}">
      <div class="admin-grid" style="flex:1">
        <div><label class="admin-label">Naam</label><input class="admin-input pj-name" value="${esc(p.name)}" /></div>
        <div><label class="admin-label">Icon</label><input class="admin-input pj-icon" value="${esc(p.icon)}" /></div>
        <div><label class="admin-label">Tag</label><input class="admin-input pj-tag" value="${esc(p.tag)}" /></div>
        <div><label class="admin-label">Status</label>
          <select class="admin-input pj-status">
            <option value="LIVE"${String(p.status).toUpperCase() === "LIVE" ? " selected" : ""}>LIVE</option>
            <option value="IN DEVELOPMENT"${String(p.status).toUpperCase() !== "LIVE" ? " selected" : ""}>IN DEVELOPMENT</option>
          </select></div>
        <div><label class="admin-label">Link (optional)</label><input class="admin-input pj-link" value="${esc(p.link || "")}" /></div>
        <div><label class="admin-label">Order</label><input class="admin-input pj-order" type="number" value="${esc(p.order || i + 1)}" /></div>
        <div class="admin-span-2"><label class="admin-label">Description</label><textarea class="admin-input pj-desc" rows="2">${esc(p.description)}</textarea></div>
      </div>
      <div class="admin-row-btns"><button class="admin-mini danger" data-del title="Delete">✕</button></div>
    </div>`
    )
    .join("");

  const rl = document.getElementById("reviewsList");
  rl.innerHTML = (SITE.reviews || [])
    .map(
      (r, i) => `
    <div class="admin-row" data-kind="review" data-i="${i}">
      <div class="admin-grid" style="flex:1">
        <div><label class="admin-label">Client Ka Naam</label><input class="admin-input rv-name" value="${esc(r.name)}" /></div>
        <div><label class="admin-label">Kaunsa Project</label><input class="admin-input rv-project" value="${esc(r.project)}" /></div>
        <div><label class="admin-label">Rating</label>
          <select class="admin-input rv-rating">
            ${[5, 4, 3, 2, 1].map((n) => `<option value="${n}"${(r.rating || 5) === n ? " selected" : ""}>${"★".repeat(n)}${"☆".repeat(5 - n)} (${n})</option>`).join("")}
          </select></div>
        <div class="admin-span-2"><label class="admin-label">Review</label><textarea class="admin-input rv-text" rows="2">${esc(r.text)}</textarea></div>
      </div>
      <div class="admin-row-btns"><button class="admin-mini danger" data-del title="Delete">✕</button></div>
    </div>`
    )
    .join("");

  sl.querySelectorAll("[data-del]").forEach((btn) =>
    btn.addEventListener("click", () => {
      SITE.services.splice(Number(btn.closest("[data-i]").dataset.i), 1);
      renderEditors();
    })
  );
  pl.querySelectorAll("[data-del]").forEach((btn) =>
    btn.addEventListener("click", () => {
      SITE.projects.splice(Number(btn.closest("[data-i]").dataset.i), 1);
      renderEditors();
    })
  );
  rl.querySelectorAll("[data-del]").forEach((btn) =>
    btn.addEventListener("click", () => {
      SITE.reviews.splice(Number(btn.closest("[data-i]").dataset.i), 1);
      renderEditors();
    })
  );
}

function getVal(id) {
  const el = document.getElementById(id);
  return el ? el.value.trim() : "";
}

function collectContent() {
  SITE.brand = {
    name: getVal("f_name") || "COSMIC",
    nameAccent: getVal("f_nameAccent") || "STORE",
    tagline: getVal("f_tagline"),
  };
  SITE.hero = {
    eyebrow: getVal("f_eyebrow"),
    title: getVal("f_title"),
    titleShine: getVal("f_titleShine"),
    subtitle: getVal("f_subtitle"),
  };
  SITE.whatsapp = getVal("f_whatsapp").replace(/[^0-9+]/g, "");
  SITE.email = getVal("f_email");

  const vals = [...document.querySelectorAll("#tab-content .st-value")].map((e) => e.value.trim());
  const labels = [...document.querySelectorAll("#tab-content .st-label")].map((e) => e.value.trim());
  SITE.stats = vals.map((v, i) => ({ value: v, label: labels[i] || "" })).filter((s) => s.value || s.label);

  SITE.services = [...document.querySelectorAll('#servicesList [data-kind="service"]')].map((row) => ({
    icon: row.querySelector(".sv-icon").value.trim() || "⭐",
    title: row.querySelector(".sv-title").value.trim() || "Service",
    desc: row.querySelector(".sv-desc").value.trim(),
  }));

  SITE.projects = [...document.querySelectorAll('#projectsList [data-kind="project"]')].map((row, i) => ({
    name: row.querySelector(".pj-name").value.trim() || "Project",
    icon: row.querySelector(".pj-icon").value.trim() || "📱",
    tag: row.querySelector(".pj-tag").value.trim(),
    status: row.querySelector(".pj-status").value,
    link: row.querySelector(".pj-link").value.trim(),
    order: Number(row.querySelector(".pj-order").value) || i + 1,
    description: row.querySelector(".pj-desc").value.trim(),
  }));

  SITE.reviews = [...document.querySelectorAll('#reviewsList [data-kind="review"]')].map((row) => ({
    name: row.querySelector(".rv-name").value.trim() || "Client",
    project: row.querySelector(".rv-project").value.trim(),
    rating: Number(row.querySelector(".rv-rating").value) || 5,
    text: row.querySelector(".rv-text").value.trim(),
  }));
}

async function saveContent() {
  collectContent();
  const btns = [document.getElementById("saveContentBtn"), document.getElementById("saveContentBtn2")];
  btns.forEach((b) => (b.disabled = true));
  const j = await window.fb.saveSite(SITE);
  if (j.ok) showToast("✓ Cloud me save! Poori duniya ko turant dikhega.");
  else showToast(j.error || "Save fail", true);
  btns.forEach((b) => (b.disabled = false));
}
document.getElementById("saveContentBtn").addEventListener("click", saveContent);
document.getElementById("saveContentBtn2").addEventListener("click", saveContent);

document.getElementById("addServiceBtn").addEventListener("click", () => {
  collectContent();
  SITE.services.push({ icon: "⭐", title: "New Service", desc: "Description yahan likho." });
  renderEditors();
});
document.getElementById("addProjectBtn").addEventListener("click", () => {
  collectContent();
  SITE.projects.push({
    name: "New Project",
    icon: "📱",
    tag: "PROJECT",
    status: "IN DEVELOPMENT",
    link: "",
    order: SITE.projects.length + 1,
    description: "Project ka description.",
  });
  renderEditors();
});
document.getElementById("addReviewBtn").addEventListener("click", () => {
  collectContent();
  SITE.reviews.push({ name: "Client Name", project: "Project", rating: 5, text: "Review text yahan." });
  renderEditors();
});

/* ============================================================
   MESSAGES (cloud inbox — live)
   ============================================================ */
let MESSAGES = [];

function watchMessages() {
  window.fb.watchMessages((list) => {
    MESSAGES = list || [];
    renderMessages();
    loadOverview();
  });
}

function renderMessages() {
  const list = document.getElementById("messagesList");
  if (!list) return;
  if (!MESSAGES.length) {
    list.innerHTML = '<div class="admin-empty">Abhi koi message nahi aaya 💬 (messages cloud me aate hain)</div>';
    return;
  }
  list.innerHTML = MESSAGES.map(
    (m) => `
    <div class="msg-card ${m.read ? "" : "unread"}">
      <div class="msg-head">
        <b>${esc(m.name)}</b>
        <span class="msg-mail">${esc(m.email || "")}${m.phone ? " · 📱 " + esc(m.phone) : ""}</span>
        <span class="msg-time">${fmtDate(m.at)}</span>
      </div>
      <div class="msg-body">${esc(m.message)}</div>
      <div class="msg-actions">
        ${m.phone ? `<a class="admin-mini" style="text-decoration:none" target="_blank" rel="noopener" href="https://wa.me/${esc(String(m.phone).replace(/[^0-9]/g, ""))}">WhatsApp Reply</a>` : ""}
        ${!m.read ? `<button class="admin-mini" data-read="${esc(m.id)}">✓ Read</button>` : ""}
        <button class="admin-mini danger" data-del="${esc(m.id)}">Delete</button>
      </div>
    </div>`
  ).join("");

  list.querySelectorAll("[data-read]").forEach((b) =>
    b.addEventListener("click", () => window.fb.markMessageRead(b.dataset.read))
  );
  list.querySelectorAll("[data-del]").forEach((b) =>
    b.addEventListener("click", async () => {
      if (!confirm("Ye message delete kar do?")) return;
      await window.fb.deleteMessage(b.dataset.del);
    })
  );
}

/* ============================================================
   OVERVIEW
   ============================================================ */
function loadOverview() {
  const now = Date.now();
  document.getElementById("ovActiveDemos").textContent = DEMOS.filter((d) => (d.expiresAt || 0) > now).length;
  document.getElementById("ovUnreadMsgs").textContent = MESSAGES.filter((m) => !m.read).length;
  document.getElementById("ovProjects").textContent = (SITE.projects || []).length;
  document.getElementById("ovServices").textContent = (SITE.services || []).length;
}

/* ============================================================
   SETTINGS
   ============================================================ */
document.getElementById("changePassBtn").addEventListener("click", async () => {
  const next = document.getElementById("newPass").value;
  const j = await window.fb.changeOwnerPassword(next);
  if (j.ok) {
    showToast("✓ Password change ho gaya!");
    document.getElementById("curPass").value = "";
    document.getElementById("newPass").value = "";
  } else {
    showToast(j.error || "Password nahi badla", true);
  }
});

document.getElementById("changePinBtn").addEventListener("click", async () => {
  const cur = document.getElementById("curPin").value.trim();
  const next = document.getElementById("newPin").value.trim();
  const j = await window.fb.changeOwnerPin(cur, next);
  if (j.ok) {
    showToast("✓ Demo PIN change ho gaya!");
    document.getElementById("curPin").value = "";
    document.getElementById("newPin").value = "";
  } else {
    showToast(j.error || "PIN nahi badla", true);
  }
});

/* ============================================================
   REFRESH ALL + TIMER
   ============================================================ */
function refreshAll() {
  loadDemos();
  loadSite();
  watchMessages();
  setTimeout(loadOverview, 800);
}

/* Time-left har 30 sec me update */
setInterval(() => {
  if (adminView.hidden) return;
  const now = Date.now();
  DEMOS.forEach((d) => {
    d.active = (d.expiresAt || 0) > now;
  });
  renderDemos();
}, 30000);
