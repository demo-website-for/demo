/* ============================================================
   COSMIC STORE — Website + Demo Control Server
   ------------------------------------------------------------
   Ek hi server sab kuch karta hai:
   1. Public website serve karta hai (public/ folder)
   2. Owner admin ka login (admin.html)
   3. Client ke liye 3-ghante ke demo accounts (demo-login.html)
   4. Demo users apni sandbox website edit kar sakte hain
   5. Contact form ke messages save karta hai

   Chalane ke liye:  npm install   →   npm start
   Phir browser me:  http://localhost:3000
   ============================================================ */

const express = require("express");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const os = require("os");

const app = express();
const PORT = process.env.PORT || 3000;

/* ------------------------------------------------------------
   DATA HELPERS — data/ folder me JSON files (koi database nahi)
   ------------------------------------------------------------ */
const DATA_DIR = path.join(__dirname, "data");
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

function dataFile(name) {
  return path.join(DATA_DIR, name);
}

function loadJSON(name, fallback) {
  try {
    const raw = fs.readFileSync(dataFile(name), "utf8");
    return JSON.parse(raw);
  } catch (_) {
    return fallback;
  }
}

/* Atomic write — pehle temp file me likho, phir rename (crash-safe) */
function saveJSON(name, data) {
  const target = dataFile(name);
  const tmp = target + ".tmp";
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2), "utf8");
  fs.renameSync(tmp, target);
}

/* ------------------------------------------------------------
   DEFAULT SITE CONTENT — pehli baar khud ban jata hai
   Owner admin panel se sab badal sakta hai (Site Content tab)
   ------------------------------------------------------------ */
const DEFAULT_SITE = {
  brand: {
    name: "COSMIC",
    nameAccent: "STORE",
    tagline: "APPS. WEBSITES. DELIVERED.",
  },
  hero: {
    eyebrow: "INDIVIDUAL APP & WEBSITE DEVELOPER",
    title: "Your Idea,",
    titleShine: "Built For Real.",
    subtitle:
      "I design and develop mobile apps, websites and admin panels for growing businesses — premium design, fast delivery, honest pricing.",
  },
  stats: [
    { value: "25+", label: "Projects Built" },
    { value: "3h", label: "Free Live Demo" },
    { value: "100%", label: "Custom Work" },
    { value: "24/7", label: "Support" },
  ],
  whatsapp: "918766204904",
  email: "hello@example.com",
  services: [
    { icon: "📱", title: "Mobile App Development", desc: "Android apps with modern UI — from your idea to Play Store launch." },
    { icon: "💻", title: "Website Development", desc: "Fast, beautiful business websites that look premium on every device." },
    { icon: "🛠️", title: "Admin Panels", desc: "Control your whole website — content, products, orders — from one panel." },
    { icon: "🛒", title: "E-Commerce Stores", desc: "Complete online store with products, cart and payment setup." },
    { icon: "🎨", title: "UI / UX Design", desc: "Clean, premium designs your customers will love at first sight." },
    { icon: "🔧", title: "Maintenance & Support", desc: "Updates, fixes and improvements — your website stays healthy." },
  ],
  projects: [
    {
      name: "ShopKart — Online Store",
      icon: "🛍️",
      tag: "E-COMMERCE",
      status: "LIVE",
      link: "",
      description: "Complete e-commerce store with admin panel, product manager and order tracking.",
      order: 1,
    },
    {
      name: "FitTrack — Fitness App",
      icon: "💪",
      tag: "ANDROID APP",
      status: "LIVE",
      link: "",
      description: "Workout planner with streaks, charts and reminders. Built for daily use.",
      order: 2,
    },
    {
      name: "GlowSalon — Booking Website",
      icon: "💅",
      tag: "BUSINESS",
      status: "LIVE",
      link: "",
      description: "Salon website with online appointment booking and WhatsApp alerts.",
      order: 3,
    },
    {
      name: "FoodDash — Delivery App",
      icon: "🍔",
      tag: "ANDROID APP",
      status: "IN DEVELOPMENT",
      link: "",
      description: "Food ordering app with live menu control from a powerful admin panel.",
      order: 4,
    },
  ],
  reviews: [
    { name: "Rahul Mehta", project: "ShopKart", rating: 5, text: "Meri dukaan ab online hai! Admin panel se khud products add karta hoon. Kaam bohot clean kiya hai." },
    { name: "Priya Sharma", project: "GlowSalon", rating: 5, text: "Website 5 din me ready mili aur bilkul waisi hai jaisi chahiye thi. Bookings badh gayi hain!" },
    { name: "Amit Verma", project: "FitTrack", rating: 5, text: "App smooth chalti hai, design premium lagta hai. Support bhi fast milta hai. Highly recommended." },
  ],
};

/* ============================================================
   DEFAULT STORE — DEMO SHOPPING WEBSITE KA DATA
   Demo client ka sandbox isi se bharta hai. Client admin panel
   se products/price badalta hai aur demo store par live dekhta
   hai. Aapki asli website (site.json) isse bilkul alag hai —
   demo me kuch bhi karo, portfolio site kabhi nahi badalti.
   ============================================================ */
const DEFAULT_STORE = {
  kind: "store",
  brand: {
    name: "AAPKI",
    nameAccent: "DUKAAN",
    tagline: "FASHION · ELECTRONICS · HOME",
  },
  announcement: "★ FREE DELIVERY ON ORDERS ABOVE ₹499 ★ COD AVAILABLE ★ EASY RETURNS ★",
  hero: {
    title: "Sab Kuch,",
    titleShine: "Ek Hi Dukaan Par.",
    subtitle:
      "Latest fashion, electronics aur ghar ke liye sab kuch — best prices, fast delivery, trusted quality.",
  },
  whatsapp: "918766204904",
  categories: [
    { icon: "👕", title: "Fashion" },
    { icon: "⌚", title: "Watches" },
    { icon: "📱", title: "Electronics" },
    { icon: "🏠", title: "Home" },
  ],
  products: [
    {
      name: "Running Shoes Pro",
      icon: "👟",
      price: 1299,
      oldPrice: 2499,
      badge: "SALE",
      status: "IN STOCK",
      description: "Ultra-light, comfortable cushioning — daily running aur walk ke liye perfect.",
      order: 1,
    },
    {
      name: "Smart Watch X2",
      icon: "⌚",
      price: 1999,
      oldPrice: 3499,
      badge: "HOT",
      status: "IN STOCK",
      description: "Heart rate, steps, call notifications — 7 din ki battery life.",
      order: 2,
    },
    {
      name: "Wireless Earbuds",
      icon: "🎧",
      price: 899,
      oldPrice: 1799,
      badge: "SALE",
      status: "IN STOCK",
      description: "Deep bass, 24 hour playtime, touch control, IPX5 waterproof.",
      order: 3,
    },
    {
      name: "Cotton T-Shirt",
      icon: "👕",
      price: 399,
      oldPrice: null,
      badge: "NEW",
      status: "IN STOCK",
      description: "100% premium cotton, size M–XXL, 6 colors available.",
      order: 4,
    },
    {
      name: "Leather Wallet",
      icon: "👛",
      price: 599,
      oldPrice: 999,
      badge: "",
      status: "IN STOCK",
      description: "Genuine leather, 6 card slots, RFID protection.",
      order: 5,
    },
    {
      name: "Laptop Backpack 30L",
      icon: "🎒",
      price: 1099,
      oldPrice: 1899,
      badge: "SALE",
      status: "OUT OF STOCK",
      description: "15.6 inch laptop compartment, waterproof, USB charging port.",
      order: 6,
    },
  ],
  reviews: [
    { name: "Anjali Sharma", project: "Smart Watch X2", rating: 5, text: "Product quality mast hai! Delivery 2 din me aa gayi, packaging bhi premium thi." },
    { name: "Rohit Kumar", project: "Running Shoes", rating: 5, text: "Price ke hisaab se best shoes. WhatsApp par hi order ho gaya, bilkul aasaan." },
    { name: "Pooja Verma", project: "Wireless Earbuds", rating: 4, text: "Sound quality is great for this price. Battery easily a full day chalti hai." },
  ],
};

/* Har demo client ka sandbox = store ki fresh copy */
function newSandbox() {
  return JSON.parse(JSON.stringify(DEFAULT_STORE));
}

/* Purane shape ke sandbox (portfolio clone) ko naye store par le aao */
function sandboxLooksValid(box) {
  return !!(box && box.kind === "store" && Array.isArray(box.products));
}

/* ------------------------------------------------------------
   BOOTSTRAP — pehli baar files banao
   ------------------------------------------------------------ */
let config = loadJSON("config.json", null);
if (!config || !config.ownerPassHash) {
  const salt = crypto.randomBytes(16).toString("hex");
  config = {
    salt,
    ownerUser: "admin",
    ownerPassHash: sha256("admin123" + salt), /* ← DEFAULT: admin / admin123 */
    passChanged: false,
  };
  saveJSON("config.json", config);
  console.log("★ Pehli baar setup: Owner login = admin / admin123 (jaldi change kar lena!)");
}

/* Demo creation ka PIN (purane config me bhi add ho jaye) */
if (!config.demoPinHash) {
  config.demoPinHash = sha256("8307248147" + config.salt); /* ← DEFAULT PIN: 8307248147 */
  saveJSON("config.json", config);
}

let site = loadJSON("site.json", null);
if (!site || !site.brand) {
  site = DEFAULT_SITE;
  saveJSON("site.json", site);
}

let demos = loadJSON("demos.json", {}); /* username → {passHash, label, createdAt, expiresAt} */
let messages = loadJSON("messages.json", []);
let sessions = loadJSON("sessions.json", {}); /* token → {role, user, expiresAt} */

function sha256(text) {
  return crypto.createHash("sha256").update(text).digest("hex");
}

/* ------------------------------------------------------------
   MIDDLEWARE
   ------------------------------------------------------------ */
app.use(express.json({ limit: "1mb" }));

/* Cookie parse (bina extra dependency) */
function parseCookies(req) {
  const out = {};
  const header = req.headers.cookie;
  if (!header) return out;
  header.split(";").forEach((part) => {
    const idx = part.indexOf("=");
    if (idx > -1) out[part.slice(0, idx).trim()] = decodeURIComponent(part.slice(idx + 1).trim());
  });
  return out;
}

/* Har request par session token dekho */
app.use((req, res, next) => {
  const token = parseCookies(req).sd_session;
  req.auth = null;
  req.demoExpired = false;
  if (token && sessions[token]) {
    const s = sessions[token];
    if (s.role === "demo") {
      /* Demo session: demo account abhi bhi valid hona chahiye */
      const d = demos[s.user];
      if (d && d.expiresAt > Date.now()) req.auth = { role: "demo", user: s.user };
      else req.demoExpired = true;
    } else if (s.expiresAt > Date.now()) {
      req.auth = { role: "owner", user: s.user };
    }
  }
  next();
});

/* No-cache for API responses (taaki demo edits turant dikhein) */
app.use("/api", (req, res, next) => {
  res.set("Cache-Control", "no-store");
  next();
});

function requireOwner(req, res, next) {
  if (!req.auth || req.auth.role !== "owner") {
    return res.status(401).json({ ok: false, error: "Owner login zaroori hai." });
  }
  next();
}

function requireDemo(req, res, next) {
  if (!req.auth || req.auth.role !== "demo") {
    if (req.demoExpired) {
      return res.status(401).json({
        ok: false,
        error: "Demo ka time khatam ho gaya. Owner se naya demo le lo.",
        code: "EXPIRED",
      });
    }
    return res.status(401).json({ ok: false, error: "Demo login zaroori hai.", code: "NEED_LOGIN" });
  }
  const d = demos[req.auth.user];
  if (!d || d.expiresAt <= Date.now()) {
    return res.status(401).json({ ok: false, error: "Demo ka time khatam ho gaya.", code: "EXPIRED" });
  }
  next();
}

/* ------------------------------------------------------------
   LOGIN RATE LIMIT — galat password par thoda break
   ------------------------------------------------------------ */
const loginFails = {}; /* key → {fails, until} */
function checkRate(key) {
  const r = loginFails[key];
  if (r && r.until > Date.now()) return false;
  return true;
}
function markFail(key) {
  const r = loginFails[key] || { fails: 0, until: 0 };
  r.fails += 1;
  if (r.fails >= 5) {
    r.until = Date.now() + 10 * 60 * 1000; /* 10 minute lock */
    r.fails = 0;
  }
  loginFails[key] = r;
}
function clearFails(key) {
  delete loginFails[key];
}

/* ------------------------------------------------------------
   SESSIONS
   ------------------------------------------------------------ */
const OWNER_SESSION_HOURS = 24;
const DEMO_SESSION_HOURS = 24;

function createSession(role, user) {
  const token = crypto.randomBytes(32).toString("hex");
  const life = role === "owner" ? OWNER_SESSION_HOURS : DEMO_SESSION_HOURS;
  sessions[token] = { role, user, expiresAt: Date.now() + life * 3600 * 1000 };
  saveJSON("sessions.json", sessions);
  return token;
}

function setSessionCookie(res, token) {
  res.setHeader(
    "Set-Cookie",
    `sd_session=${token}; HttpOnly; Path=/; SameSite=Lax; Max-Age=${24 * 3600}`
  );
}

function clearSession(req, res) {
  const token = parseCookies(req).sd_session;
  if (token && sessions[token]) {
    delete sessions[token];
    saveJSON("sessions.json", sessions);
  }
  res.setHeader("Set-Cookie", "sd_session=; HttpOnly; Path=/; SameSite=Lax; Max-Age=0");
}

/* ============================================================
   PUBLIC API
   ============================================================ */

/* Public site content (sabko dikhta hai) */
app.get("/api/site", (req, res) => {
  res.json({ ok: true, site });
});

/* Contact form — message save hota hai, admin panel me dikhta hai */
app.post("/api/contact", (req, res) => {
  const { name, email, phone, message } = req.body || {};
  if (!name || !String(name).trim() || !message || !String(message).trim()) {
    return res.status(400).json({ ok: false, error: "Naam aur message zaroori hai." });
  }
  const clean = (v, max) => String(v || "").trim().slice(0, max);
  messages.unshift({
    id: crypto.randomBytes(8).toString("hex"),
    name: clean(name, 80),
    email: clean(email, 120),
    phone: clean(phone, 20),
    message: clean(message, 3000),
    at: Date.now(),
    read: false,
  });
  if (messages.length > 200) messages.length = 200;
  saveJSON("messages.json", messages);
  res.json({ ok: true });
});

/* ============================================================
   OWNER AUTH
   ============================================================ */
app.post("/api/owner/login", (req, res) => {
  const { username, password } = req.body || {};
  const key = "o:" + (req.socket.remoteAddress || "?");
  if (!checkRate(key)) {
    return res.status(429).json({ ok: false, error: "Bahut galat tries — 10 minute baad try karo." });
  }
  const u = String(username || "").trim();
  const p = String(password || "");
  if (u === config.ownerUser && sha256(p + config.salt) === config.ownerPassHash) {
    clearFails(key);
    const token = createSession("owner", u);
    setSessionCookie(res, token);
    return res.json({ ok: true, passChanged: !!config.passChanged });
  }
  markFail(key);
  res.status(401).json({ ok: false, error: "Galat username ya password." });
});

app.post("/api/owner/logout", (req, res) => {
  clearSession(req, res);
  res.json({ ok: true });
});

app.get("/api/owner/me", requireOwner, (req, res) => {
  res.json({ ok: true, username: req.auth.user, passChanged: !!config.passChanged });
});

app.post("/api/owner/password", requireOwner, (req, res) => {
  const { current, next } = req.body || {};
  if (sha256(String(current || "") + config.salt) !== config.ownerPassHash) {
    return res.status(401).json({ ok: false, error: "Current password galat hai." });
  }
  const np = String(next || "");
  if (np.length < 6) {
    return res.status(400).json({ ok: false, error: "Naya password kam se kam 6 characters ka ho." });
  }
  config.ownerPassHash = sha256(np + config.salt);
  config.passChanged = true;
  saveJSON("config.json", config);
  res.json({ ok: true });
});

/* Demo-creation PIN badlo */
app.post("/api/owner/pin", requireOwner, (req, res) => {
  const { current, next } = req.body || {};
  if (sha256(String(current || "").trim() + config.salt) !== config.demoPinHash) {
    return res.status(401).json({ ok: false, error: "Current PIN galat hai." });
  }
  const np = String(next || "").trim();
  if (!/^[0-9]{4,12}$/.test(np)) {
    return res.status(400).json({ ok: false, error: "PIN sirf numbers me ho, 4 se 12 digits." });
  }
  config.demoPinHash = sha256(np + config.salt);
  saveJSON("config.json", config);
  res.json({ ok: true });
});

/* ============================================================
   OWNER — SITE CONTENT (public website ka content manage karo)
   ============================================================ */
app.get("/api/owner/site", requireOwner, (req, res) => {
  res.json({ ok: true, site });
});

app.put("/api/owner/site", requireOwner, (req, res) => {
  const incoming = req.body || {};
  if (!incoming.brand || !incoming.hero) {
    return res.status(400).json({ ok: false, error: "Data adhoora hai." });
  }
  site = incoming;
  saveJSON("site.json", site);
  res.json({ ok: true });
});

/* ============================================================
   OWNER — MESSAGES (contact form submissions)
   ============================================================ */
app.get("/api/owner/messages", requireOwner, (req, res) => {
  res.json({ ok: true, messages });
});

app.post("/api/owner/messages/read", requireOwner, (req, res) => {
  const { id } = req.body || {};
  const m = messages.find((x) => x.id === id);
  if (m) {
    m.read = true;
    saveJSON("messages.json", messages);
  }
  res.json({ ok: true });
});

app.delete("/api/owner/messages/:id", requireOwner, (req, res) => {
  const i = messages.findIndex((x) => x.id === req.params.id);
  if (i > -1) {
    messages.splice(i, 1);
    saveJSON("messages.json", messages);
  }
  res.json({ ok: true });
});

/* ============================================================
   OWNER — DEMO ACCOUNTS (3-ghante wale ID/PASS yahan bante hain)
   ============================================================ */
function demoPublic(d, username) {
  const now = Date.now();
  return {
    username,
    label: d.label || "",
    createdAt: d.createdAt,
    expiresAt: d.expiresAt,
    active: d.expiresAt > now,
    msLeft: Math.max(0, d.expiresAt - now),
  };
}

app.get("/api/owner/demos", requireOwner, (req, res) => {
  const list = Object.entries(demos)
    .map(([u, d]) => demoPublic(d, u))
    .sort((a, b) => b.createdAt - a.createdAt);
  res.json({ ok: true, demos: list });
});

function randomUsername() {
  const chars = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";
  let u;
  do {
    let s = "";
    for (let i = 0; i < 4; i++) s += chars[crypto.randomInt(chars.length)];
    u = "demo" + s;
  } while (demos[u]);
  return u;
}

function randomPassword() {
  const chars = "abcdefghjkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ23456789";
  let p = "";
  for (let i = 0; i < 8; i++) p += chars[crypto.randomInt(chars.length)];
  return p;
}

/* Naya demo banao — {label, hours, pin} (PIN zaroori — koi aur account na bana sake) */
app.post("/api/owner/demos", requireOwner, (req, res) => {
  const { label, hours, pin } = req.body || {};
  if (!config.demoPinHash || sha256(String(pin || "").trim() + config.salt) !== config.demoPinHash) {
    return res.status(403).json({ ok: false, error: "Galat PIN. Demo account nahi bana." });
  }
  let h = parseFloat(hours);
  if (!isFinite(h) || h <= 0 || h > 72) h = 3;
  const username = randomUsername();
  const password = randomPassword();
  const now = Date.now();
  demos[username] = {
    passHash: sha256(password + config.salt),
    label: String(label || "").trim().slice(0, 60),
    createdAt: now,
    expiresAt: now + h * 3600 * 1000,
  };
  saveJSON("demos.json", demos);
  /* Sandbox file abhi mat banao — pehli login par seed hogi */
  res.json({ ok: true, username, password, hours: h, demo: demoPublic(demos[username], username) });
});

/* Demo extend karo */
app.post("/api/owner/demos/extend", requireOwner, (req, res) => {
  const { username, hours } = req.body || {};
  const d = demos[String(username || "")];
  let h = parseFloat(hours);
  if (!isFinite(h) || h <= 0 || h > 72) h = 3;
  if (!d) return res.status(404).json({ ok: false, error: "Demo nahi mila." });
  /* Agar demo expire ho chuka hai to abhi se naye hours shuru karo */
  d.expiresAt = Math.max(d.expiresAt, Date.now()) + h * 3600 * 1000;
  saveJSON("demos.json", demos);
  res.json({ ok: true, demo: demoPublic(d, username) });
});

/* Demo delete karo (sandbox bhi) */
app.delete("/api/owner/demos/:username", requireOwner, (req, res) => {
  const u = req.params.username;
  if (!demos[u]) return res.status(404).json({ ok: false, error: "Demo nahi mila." });
  delete demos[u];
  saveJSON("demos.json", demos);
  /* Is demo ke saare sessions maar do */
  let changed = false;
  for (const [t, s] of Object.entries(sessions)) {
    if (s.role === "demo" && s.user === u) {
      delete sessions[t];
      changed = true;
    }
  }
  if (changed) saveJSON("sessions.json", sessions);
  try {
    fs.unlinkSync(dataFile("sandbox-" + sanitizeUser(u) + ".json"));
  } catch (_) {}
  res.json({ ok: true });
});

/* Demo sandbox reset karo (public site ki copy se dobara seed) */
app.post("/api/owner/demos/reset", requireOwner, (req, res) => {
  const { username } = req.body || {};
  const d = demos[String(username || "")];
  if (!d) return res.status(404).json({ ok: false, error: "Demo nahi mila." });
  saveJSON("sandbox-" + sanitizeUser(username) + ".json", newSandbox());
  res.json({ ok: true });
});

function sanitizeUser(u) {
  return String(u).toLowerCase().replace(/[^a-z0-9-]/g, "");
}

/* ============================================================
   DEMO AUTH (client login — demo-login.html)
   ============================================================ */
app.post("/api/demo/login", (req, res) => {
  const { username, password } = req.body || {};
  const u = String(username || "").trim();
  const key = "d:" + (req.socket.remoteAddress || "?") + ":" + u;
  if (!checkRate(key)) {
    return res.status(429).json({ ok: false, error: "Bahut galat tries — 10 minute baad try karo." });
  }
  const d = demos[u];
  if (!d || sha256(String(password || "") + config.salt) !== d.passHash) {
    markFail(key);
    return res.status(401).json({ ok: false, error: "Galat ID ya password. Owner se confirm karo." });
  }
  if (d.expiresAt <= Date.now()) {
    return res.status(401).json({
      ok: false,
      error: "Ye demo khatam ho gaya hai. Owner (WhatsApp) se naya demo le lo.",
      code: "EXPIRED",
    });
  }
  clearFails(key);
  /* Pehli login → sandbox seed karo (demo store ki fresh copy) */
  const sf = "sandbox-" + sanitizeUser(u) + ".json";
  const existing = loadJSON(sf, null);
  if (!sandboxLooksValid(existing)) saveJSON(sf, newSandbox());
  const token = createSession("demo", u);
  setSessionCookie(res, token);
  res.json({ ok: true, username: u, label: d.label || "", expiresAt: d.expiresAt });
});

app.post("/api/demo/logout", (req, res) => {
  clearSession(req, res);
  res.json({ ok: true });
});

app.get("/api/demo/me", requireDemo, (req, res) => {
  const d = demos[req.auth.user];
  res.json({
    ok: true,
    username: req.auth.user,
    label: d.label || "",
    expiresAt: d.expiresAt,
    msLeft: Math.max(0, d.expiresAt - Date.now()),
  });
});

/* Demo user ka sandbox content dekho */
app.get("/api/demo/site", requireDemo, (req, res) => {
  const sf = "sandbox-" + sanitizeUser(req.auth.user) + ".json";
  let box = loadJSON(sf, null);
  if (!sandboxLooksValid(box)) {
    box = newSandbox();
    saveJSON(sf, box);
  }
  res.json({ ok: true, site: box });
});

/* Demo user apna sandbox edit karo (demo admin panel se) */
app.put("/api/demo/site", requireDemo, (req, res) => {
  const incoming = req.body || {};
  if (!incoming.brand || !Array.isArray(incoming.products)) {
    return res.status(400).json({ ok: false, error: "Data adhoora hai." });
  }
  incoming.kind = "store";
  saveJSON("sandbox-" + sanitizeUser(req.auth.user) + ".json", incoming);
  res.json({ ok: true });
});

/* Sandbox reset — wapas demo store ki fresh copy */
app.post("/api/demo/reset", requireDemo, (req, res) => {
  saveJSON("sandbox-" + sanitizeUser(req.auth.user) + ".json", newSandbox());
  res.json({ ok: true });
});

/* ============================================================
   CLEANUP — purane expire hue demos + sessions hatao
   ============================================================ */
function cleanup() {
  const now = Date.now();
  let dChanged = false;
  for (const [u, d] of Object.entries(demos)) {
    /* 48 ghante se zyada purana expire demo → delete (sandbox ke saath) */
    if (d.expiresAt < now - 48 * 3600 * 1000) {
      delete demos[u];
      dChanged = true;
      try {
        fs.unlinkSync(dataFile("sandbox-" + sanitizeUser(u) + ".json"));
      } catch (_) {}
    }
  }
  if (dChanged) saveJSON("demos.json", demos);

  let sChanged = false;
  for (const [t, s] of Object.entries(sessions)) {
    if (s.expiresAt < now) {
      delete sessions[t];
      sChanged = true;
    }
  }
  if (sChanged) saveJSON("sessions.json", sessions);
}
cleanup();
setInterval(cleanup, 60 * 60 * 1000);

/* ============================================================
   STATIC FILES — public/ folder = poori website
   ============================================================ */
app.use(express.static(path.join(__dirname, "public")));

/* ============================================================
   START
   ============================================================ */
app.listen(PORT, "0.0.0.0", () => {
  console.log("");
  console.log("  ✦ COSMIC STORE website chal rahi hai ✦");
  console.log("");
  console.log("  Apne computer par:  http://localhost:" + PORT);
  const nets = os.networkInterfaces();
  for (const list of Object.values(nets)) {
    for (const n of list || []) {
      if (n.family === "IPv4" && !n.internal) {
        console.log("  WiFi/phone par:     http://" + n.address + ":" + PORT);
      }
    }
  }
  console.log("");
  console.log("  Owner Admin:  http://localhost:" + PORT + "/admin.html");
  console.log("  Demo Login:   http://localhost:" + PORT + "/demo-login.html");
  console.log("");
});
